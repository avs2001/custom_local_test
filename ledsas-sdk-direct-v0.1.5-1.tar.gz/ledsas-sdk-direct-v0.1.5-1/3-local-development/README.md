# Local Development Environment

This directory contains Docker Compose configuration for running local infrastructure needed for LEDSAS SDK Direct Mode development.

---

## What's Included

**Services:**
- **RabbitMQ 3.12** - Message queue for request/response communication
- **Azurite** - Azure Blob Storage emulator for local blob operations

**Not Included:**
- Sidecar (not needed in Direct Mode - your service connects directly)
- Production security features
- Kubernetes components

---

## Quick Start

### Start Services

```bash
docker compose up -d
```

This starts RabbitMQ and Azurite in the background.

### Check Status

```bash
docker compose ps
```

Expected output:
```
NAME                      IMAGE                                    STATUS
ledsas-rabbitmq-direct    rabbitmq:3.12-management-alpine         Up (healthy)
ledsas-azurite-direct     mcr.microsoft.com/azure-storage/azurite Up (healthy)
```

### View Logs

```bash
# All services
docker compose logs -f

# Specific service
docker compose logs -f rabbitmq
docker compose logs -f azurite
```

### Stop Services

```bash
docker compose down
```

**Note:** This preserves data volumes. To delete volumes:
```bash
docker compose down -v
```

---

## Service Details

### RabbitMQ

**AMQP Protocol:**
- Host: `localhost`
- Port: `5672`
- Username: `guest`
- Password: `guest`
- Connection URL: `amqp://guest:guest@localhost:5672/`

**Management UI:**
- URL: `http://localhost:15672`
- Username: `guest`
- Password: `guest`

**Management UI Features:**
- View queues and exchanges
- Monitor message rates
- Manually publish/consume messages
- View connections and channels

### Azurite (Azure Storage Emulator)

**Blob Service:**
- Endpoint: `http://127.0.0.1:10000/devstoreaccount1`
- Account Name: `devstoreaccount1`
- Account Key: `Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==`

**Connection String:**
```
DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;
```

**Queue Service:** Port `10001`
**Table Service:** Port `10002`

---

## Environment Variables

Use the provided `.env.example` file:

### Copy and Customize

```bash
cp .env.example .env
# Edit .env as needed
```

### Load Variables

**Option 1: Export**
```bash
export $(cat .env | xargs)
```

**Option 2: Source with set**
```bash
set -a
source .env
set +a
```

**Option 3: Inline**
```bash
export KBM_LEDSAS_MODE=direct
export KBM_LEDSAS_RABBITMQ_URL=amqp://guest:guest@localhost:5672/
export KBM_LEDSAS_BLOB_CONN_STRING="DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;"
```

---

## Troubleshooting

### Port Conflicts

**Symptom:** `Error: port already allocated`

**Solution:**
1. Check what's using the port:
   ```bash
   lsof -i :5672   # RabbitMQ
   lsof -i :10000  # Azurite
   ```
2. Stop conflicting service or edit `docker-compose.yml` to change ports

### Service Not Healthy

**Symptom:** Container shows "(unhealthy)" status

**Solution:**
```bash
# Check logs
docker compose logs rabbitmq
docker compose logs azurite

# Restart service
docker compose restart rabbitmq
docker compose restart azurite
```

### Cannot Connect from Service

**Symptom:** Connection refused errors in your Python service

**Solution:**
1. Verify services are running: `docker compose ps`
2. Check if using correct host (`localhost` not `127.0.0.1` for some systems)
3. Verify environment variables are loaded
4. Check firewall/security software

### Azurite API Version Error

**Symptom:** Error message: `The API version 2026-02-06 is not supported by Azurite`

**Cause:** The SDK's Azure Blob client uses an API version newer than your Azurite supports.

**Solution:** The docker-compose.yml in this package already includes the `--skipApiVersionCheck` flag. If you're using an older version of the package, update the Azurite command:

```yaml
command: azurite --blobHost 0.0.0.0 --queueHost 0.0.0.0 --tableHost 0.0.0.0 --skipApiVersionCheck
```

Then restart: `docker compose down && docker compose up -d`

### Data Persistence

**Data is stored in Docker volumes:**
- `ledsas-rabbitmq-data-direct` - RabbitMQ queues and messages
- `ledsas-azurite-data-direct` - Blob storage data

**View volumes:**
```bash
docker volume ls | grep ledsas
```

**Delete volumes (WARNING: deletes all data):**
```bash
docker compose down -v
```

---

## Using RabbitMQ Management UI

1. Open `http://localhost:15672`
2. Login with `guest` / `guest`
3. Navigate to **Queues** tab
4. See your service's request/response queues
5. Manually publish test messages (useful for debugging)

---

## Using Azure Storage Explorer (Optional)

To browse Azurite blob storage visually:

1. Download **Azure Storage Explorer** (free)
2. Connect to local storage account:
   - Account name: `devstoreaccount1`
   - Account key: `Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==`
   - Use HTTP endpoints
3. Browse containers and blobs

---

## Next Steps

1. Start services: `docker compose up -d`
2. Load environment variables (see above)
3. Run example service: `cd ../2-documentation/examples && python simple_csv_processor.py`
4. Test your service with RabbitMQ messages

---

## Production Deployment

**IMPORTANT:** This Docker Compose setup is for **development only**.

For production deployment:
- Request the **full package** from KeborMed
- Follow the **Production Deployment Guide**
- Use sidecar for security
- Deploy to Kubernetes with Istio

---

## Support

For questions:
- See main README: `../README.md`
- See Quick Start Guide: `../2-documentation/QUICKSTART_DIRECT_MODE.md`
- Contact KeborMed support
