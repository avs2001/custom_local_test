# LEDSAS SDK API Reference v0.2.0 (Production Mode)

The customer-facing API surface — `ServiceApp`, `ExecutionContext`,
errors, models — is **identical** to direct mode. Your handler code
runs unchanged when you switch `KBM_LEDSAS_MODE` between `direct` and
`production`. This document covers what changes at the *configuration*
and *transport* layer when running in production mode.

For the full surface (handler signatures, message envelope shape,
`ctx.blob.*` calls, error semantics, health endpoints), refer to the
direct-mode API reference. This document covers only the production-
specific deltas.

---

## Public vs Internal Modules

| Public | `from kbm_ledsas_sdk import ServiceApp, ExecutionContext, errors` |
|--------|---|
|        | `from kbm_ledsas_sdk.models import BlobRef` |
|        | Every class, method, env var, and behaviour in this file. |
| Internal | `kbm_ledsas_sdk.transport.*`, `kbm_ledsas_sdk.amqp.*`, `kbm_ledsas_sdk.runtime.*`, `kbm_ledsas_sdk.blob.*`, `kbm_ledsas_sdk.health.*`, `kbm_ledsas_sdk.utils.*` |

Internal modules may change layout, signatures, or be removed in any
point release with no deprecation period.

---

## Environment Variables (Production Mode)

| Variable | Default | Description |
|----------|---------|-------------|
| `KBM_LEDSAS_MODE` | _(inferred)_ | Set to `production`. Whitespace- and case-tolerant. Inferred to `production` when `KBM_LEDSAS_SOCKET_PATH` is set; setting it explicitly is clearer. |
| `KBM_LEDSAS_SOCKET_PATH` | `/run/kbm-ledsas/agent.sock` | Path to the sidecar's UDS socket. MUST match the sidecar's `SOCKET_PATH`. |
| `KBM_LEDSAS_SERVICE_NAME` | Required | Service name. Validated `^[A-Za-z0-9][A-Za-z0-9._\-]*$`, 1..64 chars. MUST match the sidecar's `SERVICE_NAME`. |
| `KBM_LEDSAS_TENANT` | _(unset)_ | Optional tenant prefix. If set, MUST match the sidecar's `TENANT`. |
| `KBM_LEDSAS_CONCURRENCY` | `4` | Max concurrent handlers. |
| `KBM_LEDSAS_LOG_LEVEL` | `INFO` | Log level for the `kbm_ledsas_sdk` logger. |
| `KBM_LEDSAS_LOG_FORMAT` | `json` | `json` (machine-parseable) or `text`. |
| `KBM_LEDSAS_HANDLER_TIMEOUT` | `1800` | Handler timeout in seconds (`0` disables; max `86400`). |
| `KBM_LEDSAS_GENERIC_ERRORS` | `false` | Fallback to generic message when handler did not set `user_message`. |
| `KBM_LEDSAS_HEALTH_PORT` | `8090` | HTTP port for SDK-side `/health`. `0` disables. The sidecar exposes its own health on port `8080`. |
| `KBM_LEDSAS_HEALTH_HOST` | `127.0.0.1` | Bind address for the SDK health server. |
| `KBM_LEDSAS_DEBUG` | `0` | If `1`, dump full traceback on configuration-error startup failures. |

### Variables That Don't Apply in Production Mode

The following direct-mode env vars are **not** consulted in production
mode (they're consumed by the sidecar, not the SDK):

- `KBM_LEDSAS_RABBITMQ_URL` — sidecar uses `RABBITMQ_HOST` etc.
- `KBM_LEDSAS_BLOB_CONN_STRING` — sidecar uses `BLOB_CONN_STRING`
- `KBM_LEDSAS_CONTAINER` — sidecar uses `BLOB_CONTAINER`
- `KBM_LEDSAS_PREFETCH` — sidecar uses `PREFETCH`
- `KBM_LEDSAS_MAX_RETRIES` — sidecar uses `MAX_RETRY_ATTEMPTS`
- `KBM_LEDSAS_MAX_PAYLOAD_BYTES` — sidecar enforces its own cap
- `KBM_LEDSAS_ALLOW_INSECURE_AMQP` — sidecar enforces

Setting them in production mode is harmless (the SDK ignores them),
but it can mislead readers about where the value actually takes
effect.

---

## Blob Operations Over UDS

The customer-facing API is identical to direct mode:

```python
@app.handler("ProcessData")
async def handle(ctx, req):
    data = await ctx.blob.download_bytes(req["input_uri"])
    out_ref = await ctx.blob.upload_bytes(
        container="results",
        data=do_work(data),
        path=f"out/{ctx.message_id}.json",
        overwrite=True,
    )
    return {"output_uri": out_ref.uri}
```

What changes under the hood:

| Operation | Direct mode | Production mode |
|-----------|-------------|-----------------|
| `download_bytes` | Azure SDK call directly | JSON-RPC `blob.download` to sidecar; sidecar pulls from Azure |
| `upload_bytes` | Azure SDK call directly | JSON-RPC `blob.upload` to sidecar; sidecar pushes to Azure |
| `get_blob_size` | Azure SDK call directly | JSON-RPC `blob.get_size` |
| `download_stream` (≥10 MiB) | Azure SDK chunked download | JSON-RPC `blob.get_chunk` loop |
| `download_to_file` | (not exposed in direct mode) | JSON-RPC `blob.download_to_file` |
| `upload_from_file` | (not exposed in direct mode) | JSON-RPC `blob.upload_from_file` |

### Per-Request Size Cap

Each JSON-RPC message between SDK and sidecar is capped at **10 MiB** (binary, `10 * 1024 * 1024` bytes).
The SDK transparently routes around this for large payloads:

- `upload_bytes`, `upload_text`, `upload_json`, `upload_stream`: payloads
  below 4 MiB go through `blob.upload` in a single RPC. Payloads at or
  above 4 MiB are transparently chunked through
  `blob.upload_init` / `blob.upload_chunk` / `blob.upload_complete`
  (new in v0.2.0 — see "Chunked upload" below). Maximum single-blob
  upload is **256 MiB**.
- `download_stream`: the SDK auto-switches to chunked mode at 10 MiB
  blob size — uses 4 MiB RPC chunks; no customer code change needed.

### Chunked upload (v0.2.0)

At the JSON-RPC level, large uploads (≥ 4 MiB) flow over three new methods:

**`blob.upload_init`**

```json
// SDK → sidecar
{
  "container": "myc",
  "path": "results/output.csv",
  "total_size": 12582912,
  "sha256": "9d1c54ab…64 lowercase hex…",
  "overwrite": true,
  "chunk_size": 4194304
}
// sidecar → SDK
{ "session_id": "upl_a1b2c3…32 lowercase hex…" }
```

Constraints (sidecar-enforced):

- `total_size` must be > 0 and ≤ 256 MiB (`256 * 1024 * 1024`)
- `chunk_size` must be > 0 and ≤ 4 MiB (`4 * 1024 * 1024`)
- `sha256` is optional; if present must match `^[0-9a-f]{64}$`
- `overwrite` must be a boolean
- `path` is optional (sidecar auto-generates a UUID-based path)

**`blob.upload_chunk`** — called N times in strict index order:

```json
// SDK → sidecar
{
  "session_id": "upl_a1b2c3…",
  "chunk_index": 0,
  "data": "<base64 of up to chunk_size bytes>"
}
// sidecar → SDK
{ "received_bytes": 4194304, "next_chunk_index": 1 }
```

`data_base64` is accepted as a legacy alias for one release (same
transition window v0.1.8 opened for `blob.upload`). Out-of-order
chunks, oversize chunks, and chunks that would push cumulative bytes
past the declared `total_size` are rejected with `INVALID_PARAMS`.

**`blob.upload_complete`** — finalizes and pushes to Azure:

```json
// SDK → sidecar
{ "session_id": "upl_a1b2c3…" }
// sidecar → SDK
{
  "uri": "azblob://myc/results/output.csv?versionId=…",
  "etag": null,
  "version_id": null,
  "size": 12582912
}
```

If `sha256` was given at `upload_init`, the sidecar recomputes it over
the assembled buffer and rejects on mismatch. The session is
discarded whether commit succeeds or fails.

**Session lifetime:** 300 s from `upload_init`. A session not
completed within the window is GC'd by the sidecar. Sessions are
scoped to a single UDS connection — a different SDK client cannot
guess your session id (it's `upl_` + 32 random hex from
`secrets.token_hex`).

---

## Compatibility with the Sidecar

The SDK's UDS RPC contract is locked by a generated contract test
(`kbm_ledsas_sdk/tests/contracts/test_rpc_field_symmetry.py`). The
v0.1.8 release closes a latent bug where the SDK sent `data_base64`
on `blob.upload` and the sidecar read `data` — every UDS-mode
`upload_bytes` returned `INVALID_PARAMS`. The fix:

| Side | Change |
|------|--------|
| SDK | Sends canonical key `data` (was `data_base64`). |
| Sidecar | Reads `data`; also accepts legacy `data_base64` for one release as a transition window. Logs DEBUG when the legacy form is received. |

Mixing a v0.1.8 SDK with an older sidecar still works because the
SDK now sends the canonical key. Mixing an older SDK with a v0.1.8
sidecar also works because the sidecar still reads the legacy key.
Two old components (SDK ≤ v0.1.7 + sidecar ≤ v0.1.7) is the only
broken combination — upgrade one side to v0.1.8 to recover.

A second symmetry fix in v0.1.8: `blob.upload` now actually forwards
the `overwrite=True/False` parameter from SDK to Azure. Pre-fix, the
SDK passed `overwrite=True` and the sidecar silently dropped the
field (hardcoded `overwrite=False` further down the chain), so
calls expecting to overwrite an existing blob raised at Azure
instead of succeeding.

---

## Error Mapping (UDS → SDK)

When the sidecar returns a JSON-RPC error, the SDK maps it to one of:

| JSON-RPC error code | SDK exception | Retryable? |
|--------------------|---------------|-----------|
| `-32602` (INVALID_PARAMS) | `errors.Permanent` | No |
| `-32603` (INTERNAL_ERROR) | `errors.Retryable` | Yes |
| `-32601` (METHOD_NOT_FOUND) | `errors.Permanent` | No |

The sidecar logs the full error context (including stack trace if
available) on its side; the SDK only sees the code + message.

---

## ExecutionContext

Identical to direct mode. `ctx.deadline`, `ctx.message_id`,
`ctx.correlation_id`, `ctx.trace_id`, `ctx.blob.*` all behave the
same — but `ctx.blob.*` routes through UDS instead of Azure SDK.

---

## AMQP Topology

Owned by the sidecar in production mode. The customer service does
NOT declare exchanges or queues directly. The topology pattern
matches direct mode:

| Component | Name pattern | Type |
|-----------|--------------|------|
| Command Exchange | `[{tenant}.]cmd.{service_name}.v1` | TOPIC |
| Command Queue | `[{tenant}.]queue.{service_name}.v1` | — |
| DLQ Exchange | `[{tenant}.]dlq.{service_name}.v1` | TOPIC |
| DLQ Queue | `[{tenant}.]dlq.queue.{service_name}.v1` | — |

The sidecar enforces the `tenant + service_name + 14 ≤ 127` budget
at startup (refuses to declare topology that would violate the
RabbitMQ-protocol cap on names). If the sidecar refuses to start,
shorten `SERVICE_NAME` or `TENANT`.

---

## Health Endpoints

The SDK and the sidecar each expose their own health server.

| Endpoint | Owner | Port (default) |
|----------|-------|----------------|
| SDK `/health`, `/ready`, `/livez`, `/readyz` | SDK process | `8090` (`KBM_LEDSAS_HEALTH_PORT`) |
| Sidecar `/health`, `/livez`, `/readyz` | Sidecar process | `8080` (`HEALTH_PORT`) |

Both servers strip the `Server: Python/aiohttp/...` header on
every response and return JSON for 200/404/405.

---

## Logging

Both the SDK and the sidecar log structured JSON to stdout. Each SDK
log record carries `service_name` (set by `ServiceNameFilter` —
attached at handler level so every child logger inherits it).

Credentials are scrubbed: any AMQP URL appearing in a log line has
its user/password replaced with `***:***@`.

---

## Where to Go Next

- For the unchanged surface (`ServiceApp`, handler signatures,
  envelope shape, blob ops, errors, message format): the direct-mode
  API reference is the source of truth.
- For deployment: see `2-kubernetes-deployment/`.
- For sidecar operations (env vars, signals, probes): see
  `2-kubernetes-deployment/sidecar-startup.md`.
