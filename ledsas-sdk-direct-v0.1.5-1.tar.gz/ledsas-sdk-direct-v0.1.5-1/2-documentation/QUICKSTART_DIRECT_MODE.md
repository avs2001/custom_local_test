# Quick Start Guide: LEDSAS SDK Direct Mode

**Version:** 0.1.5-1
**Last Updated:** 2026-01-21

This guide will help you build and test your first LEDSAS microservice in Direct Mode using local infrastructure.

**Estimated Time:** 30 minutes

---

## Prerequisites

Before starting, ensure you have:

- **Python 3.11+** installed (`python --version`)
- **pip** installed (`pip --version`)
- **Docker** and **Docker Compose** installed (`docker --version`, `docker compose version`)
- Basic understanding of:
  - Python async/await
  - RabbitMQ message queues
  - Azure Blob Storage (or similar object storage)

---

## Step 1: Install the SDK (5 minutes)

### 1.1 Navigate to SDK Directory

```bash
cd 1-sdk
```

### 1.2 Install SDK Wheel

```bash
pip install kbm_ledsas_sdk-0.1.5-py3-none-any.whl
```

**Verify Installation:**

```bash
python -c "from kbm_ledsas_sdk import ServiceApp; print('SDK installed successfully!')"
```

You should see: `SDK installed successfully!`

### 1.3 Install Dependencies (Optional)

If your service needs additional dependencies:

```bash
pip install -r requirements.txt
```

---

## Step 2: Start Local Infrastructure (5 minutes)

### 2.1 Navigate to Local Development

```bash
cd ../3-local-development
```

### 2.2 Start Docker Services

```bash
docker compose up -d
```

This starts:
- **RabbitMQ** on `localhost:5672` (AMQP protocol)
- **RabbitMQ Management UI** on `http://localhost:15672` (user: `guest`, pass: `guest`)
- **Azurite** (Azure Storage emulator) on `localhost:10000`

### 2.3 Verify Services Running

```bash
docker compose ps
```

You should see both services in "running" state.

**Troubleshooting:**
- If port conflicts occur, see "Common Issues" section below
- Check logs: `docker compose logs rabbitmq` or `docker compose logs azurite`

---

## Step 3: Run Example Service (10 minutes)

### 3.1 Set Environment Variables

```bash
export KBM_LEDSAS_MODE=direct
export KBM_LEDSAS_RABBITMQ_URL=amqp://guest:guest@localhost:5672/
export KBM_LEDSAS_BLOB_CONN_STRING="DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;"
```

**Environment Variables Explained:**

- `KBM_LEDSAS_MODE=direct` - Use Direct Mode (no sidecar)
- `KBM_LEDSAS_RABBITMQ_URL` - Local RabbitMQ connection string
- `KBM_LEDSAS_BLOB_CONN_STRING` - Azurite connection string (default credentials)

### New in v0.1.5: Error Handling Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `KBM_LEDSAS_HANDLER_TIMEOUT` | `1800` | Handler execution timeout in seconds. Set to `0` to disable. |
| `KBM_LEDSAS_MAX_RETRIES` | `3` | Maximum retry attempts before sending to DLQ. |
| `KBM_LEDSAS_GENERIC_ERRORS` | `false` | Return generic error messages to callers (hides internal details). |

**Example with timeout and generic errors:**

```bash
export KBM_LEDSAS_HANDLER_TIMEOUT=300      # 5 minute timeout
export KBM_LEDSAS_MAX_RETRIES=5            # 5 retry attempts
export KBM_LEDSAS_GENERIC_ERRORS=true      # Hide error details from callers
```

### 3.2 Run Direct Mode Example

```bash
cd ../2-documentation/examples
python direct_mode_example.py
```

**Expected Output:**

```
Starting CSV Processor service...
Listening for CSV processing requests on queue: csv-processor-requests
Press Ctrl+C to stop
```

### 3.3 Setup Test Data in Azurite

Before sending test requests, create a container and upload test data:

```bash
# Install Azure CLI (if not installed)
# brew install azure-cli  # macOS
# apt-get install azure-cli  # Ubuntu

# Set Azurite connection string
export AZURE_STORAGE_CONNECTION_STRING="DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;"

# Create container
az storage container create --name test-container --connection-string "$AZURE_STORAGE_CONNECTION_STRING"

# Create sample CSV test data
echo -e "name,value\nrow1,100\nrow2,200\nrow3,300" > /tmp/sample.csv

# Upload test file
az storage blob upload \
    --container-name test-container \
    --file /tmp/sample.csv \
    --name sample.csv \
    --connection-string "$AZURE_STORAGE_CONNECTION_STRING"

# Also create output container for results
az storage container create --name output --connection-string "$AZURE_STORAGE_CONNECTION_STRING"
```

**Alternative: Use Azure Storage Explorer**
- Download from: https://azure.microsoft.com/en-us/products/storage/storage-explorer/
- Connect using the Azurite connection string
- Create containers and upload files via GUI

### 3.4 Send Test Request

Open a **second terminal** and send a test message:

```bash
# Install pika for sending test messages
pip install pika

# Send test request (example script)
python - <<EOF
import pika
import json
import uuid
from datetime import datetime, timezone

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# The SDK creates exchanges/queues automatically based on service_name
# For service "csv-processor-direct", the exchange is "cmd.csv-processor-direct.v1"
exchange_name = "cmd.csv-processor-direct.v1"

# IMPORTANT: SDK expects messages in Command format with envelope + payload
message_id = str(uuid.uuid4())
request = {
    "envelope": {
        "schema_version": "1.0",
        "type": "command",
        "name": "ProcessCSV",           # Must match handler name (case-sensitive!)
        "message_version": "1.0",
        "message_id": message_id,
        "correlation_id": str(uuid.uuid4()),
        "idempotency_key": str(uuid.uuid4()),
        "sent_at": datetime.now(timezone.utc).isoformat(),
        "trace_id": str(uuid.uuid4()),
        "reply_to": ""                  # Optional: where to send response
    },
    "payload": {
        "csv_uri": "azblob://test-container/sample.csv"
    }
}

# Publish to the service's command exchange
channel.basic_publish(
    exchange=exchange_name,
    routing_key="#",
    body=json.dumps(request),
    properties=pika.BasicProperties(
        content_type="application/json",
        delivery_mode=2  # Persistent
    )
)

print(f"Test request sent! Message ID: {message_id}")
connection.close()
EOF
```

**Note:** The SDK expects messages in a specific format:
- `envelope`: Contains routing metadata (message_id, correlation_id, etc.)
- `payload`: Contains your actual request data (passed to handler as `req`)

Your service should process the request and log the activity.

---

## Step 4: Build Your Service (10+ minutes)

### 4.1 Study Examples

1. **Start with simple_csv_processor.py**
   ```bash
   cat 2-documentation/examples/simple_csv_processor.py
   ```
   This is a minimal example showing the core SDK usage pattern.

2. **Review direct_mode_example.py**
   More complete example with error handling and blob operations.

3. **Extract POC Source Code** (optional)
   ```bash
   cd ../4-reference
   tar -xzf poc-service-source-0.1.5.tar.gz
   ```

### 4.2 Create Your Service

**Basic Service Template:**

```python
import logging
from kbm_ledsas_sdk import ServiceApp

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create the service application
app = ServiceApp(service_name="my-data-processor")


@app.handler
async def handle_request(ctx, req: dict) -> dict:
    """
    Handle incoming request.

    Args:
        ctx: ExecutionContext with blob operations, message metadata
        req: The payload dict from the incoming message

    Returns:
        dict: Response to send back
    """
    logger.info(f"Processing request: {ctx.message_id}")

    # 1. Access request data (from payload)
    input_data = req.get("input_data")

    # 2. Process data
    result = process_data(input_data)

    # 3. Upload result to blob storage
    result_ref = await ctx.blob.upload_json(
        container="output",
        obj=result,
        path=f"result-{ctx.message_id}.json"
    )

    # 4. Return response
    return {
        "result_uri": result_ref.uri,
        "status": "success"
    }


def process_data(input_data):
    """Your business logic here"""
    # TODO: Implement your processing logic
    return {"processed": True, "input": input_data}


if __name__ == "__main__":
    logger.info("Starting service...")
    app.run()
```

**Key Points:**
- Use `ServiceApp` - it auto-selects DirectTransport when `KBM_LEDSAS_MODE=direct`
- The `@app.handler` decorator registers your handler function
- `ctx` provides access to `blob` operations, `message_id`, `correlation_id`, etc.
- `req` is the `payload` dict from the incoming message

### 4.3 Test Your Service

1. Set environment variables (see Step 3.1)
2. Run your service: `python your_service.py`
3. Send test requests via RabbitMQ
4. Verify results in Azurite blob storage

---

## Step 5: Develop Iteratively

### Development Workflow

1. **Make code changes** to your service
2. **Restart service** (`Ctrl+C`, then run again)
3. **Send test requests**
4. **Check logs and results**
5. **Repeat** until service works as expected

### View RabbitMQ Activity

Open RabbitMQ Management UI:
```
http://localhost:15672
Username: guest
Password: guest
```

Navigate to **Queues** tab to see message activity.

### View Blob Storage

Use Azure Storage Explorer or `az storage` CLI to browse Azurite:
- Connection string is the same as `KBM_LEDSAS_BLOB_CONN_STRING`
- Blob endpoint: `http://127.0.0.1:10000/devstoreaccount1`

---

## Common Issues

### Issue: Port Already in Use

**Symptom:** Docker Compose fails with "port already allocated"

**Solution:**
1. Check what's using the port:
   ```bash
   lsof -i :5672   # RabbitMQ
   lsof -i :10000  # Azurite
   ```
2. Stop the conflicting service or change ports in `docker-compose.yml`

### Issue: SDK Import Error

**Symptom:** `ModuleNotFoundError: No module named 'kbm_ledsas_sdk'`

**Solution:**
```bash
pip install --force-reinstall 1-sdk/kbm_ledsas_sdk-0.1.5-py3-none-any.whl
```

### Issue: Connection Refused

**Symptom:** Service can't connect to RabbitMQ or Azurite

**Solution:**
1. Verify services are running: `docker compose ps`
2. Check logs: `docker compose logs`
3. Restart services: `docker compose restart`

### Issue: Blob Upload Fails

**Symptom:** BlobOperations upload returns error

**Solution:**
1. Verify Azurite is running
2. Create container first (containers are not auto-created)
3. Use Azure Storage Explorer to create containers manually

### Issue: Azurite API Version Not Supported

**Symptom:** Error message like:
```
The API version 2026-02-06 is not supported by Azurite. Please upgrade Azurite to latest version and retry.
```

**Cause:** The SDK uses `azure-storage-blob` which requires a newer Azure Blob API version than your Azurite version supports.

**Solution:**

**Option 1: Update docker-compose.yml (Recommended)**

Add `--skipApiVersionCheck` flag to the Azurite command:

```yaml
azurite:
  image: mcr.microsoft.com/azure-storage/azurite:latest
  command: azurite --blobHost 0.0.0.0 --queueHost 0.0.0.0 --tableHost 0.0.0.0 --skipApiVersionCheck
```

Then restart Azurite:
```bash
docker compose down
docker compose up -d
```

**Option 2: Add flag to existing Azurite container**

If you're already running Azurite, stop it and restart with the flag:
```bash
docker compose down azurite
docker compose up -d azurite
```

**Note:** The `--skipApiVersionCheck` flag is safe for development/testing. It tells Azurite to accept requests regardless of the API version header.

---

## Next Steps

### When Your Service Works

1. Validate your service logic thoroughly
2. Add comprehensive error handling
3. Write unit and integration tests
4. Document your service API

### Ready for Production?

When your service is stable and tested in Direct Mode:

1. **Request the Full Package** from KeborMed
2. Follow the **Production Deployment Guide** (included in full package)
3. Deploy to Kubernetes with sidecar for security

**Full Package Includes:**
- Production mode sidecar container
- Kubernetes deployment manifests
- Security hardening guide
- Compliance documentation
- Production monitoring and observability

---

## SDK API Reference

For complete SDK documentation, see:
```
2-documentation/SDK_API_REFERENCE.md
```

Key SDK components:
- `ServiceApp` - Main entry point (auto-selects transport based on mode)
- `ExecutionContext` - Request context with metadata and operations
- `ctx.blob` - Azure Blob Storage operations (upload/download)
- Error types: `Retryable`, `Permanent`, `DeadlineExceeded`

---

## Troubleshooting Tips

1. **Enable debug logging:**
   ```bash
   export KBM_LEDSAS_LOG_LEVEL=DEBUG
   ```

2. **Check Docker services:**
   ```bash
   docker compose ps
   docker compose logs --tail 50
   ```

3. **Verify environment variables:**
   ```bash
   env | grep KBM_LEDSAS
   ```

4. **Test RabbitMQ connectivity:**
   ```bash
   telnet localhost 5672
   ```

5. **Test Azurite connectivity:**
   ```bash
   curl http://localhost:10000
   ```

---

## Support

For additional help:
- Review `SDK_API_REFERENCE.md` for API details
- Check example code in `2-documentation/examples/`
- Contact KeborMed support

---

**You're ready to build!** Start with `simple_csv_processor.py` and iterate from there.
