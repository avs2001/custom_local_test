# Path to Production — Production Mode (UDS Sidecar)

This guide walks through everything needed to take a LEDSAS service from local
development to a Kubyk production deployment **using the production-mode SDK
talking to a `kbm-ledsas-agent` sidecar over Unix Domain Socket**.

For the canonical contract spec, see
[`docs/dhf/kubyk-contract.md`](../../docs/dhf/kubyk-contract.md). This guide is
the customer-facing walkthrough for production mode specifically.

---

## What "production mode" means

Production mode separates the broker + blob handling from your service code.
The sidecar holds the credentials and manages the AMQP / Azure Blob
connections; your service talks to the sidecar over a Unix Domain Socket via
JSON-RPC.

```
   Kubyk-deployed Pod
   ┌─────────────────────────────────────────────┐
   │  your-service:<tag>                         │
   │   ├── kbm_ledsas_sdk (production mode)      │
   │   ├── your main.py                          │
   │   └── env vars: SOCKET_PATH + SERVICE_NAME  │
   │                          │                  │
   │                          ▼  /run/.../sock   │
   │  kbm-ledsas-agent:<tag>                     │
   │   ├── reads RabbitMQ + Blob credentials     │
   │   ├── exposes JSON-RPC over UDS             │
   │   └── env vars: KBM_LEDSAS_RABBITMQ_URL,    │
   │                  KBM_LEDSAS_BLOB_CONN_STRING│
   └──────────┬─────────────────────────┬────────┘
              │                         │
       ┌──────▼──────┐         ┌────────▼─────────┐
       │  RabbitMQ   │         │  Azure Blob      │
       │  (TLS 5671) │         │  (HTTPS)         │
       └─────────────┘         └──────────────────┘
```

Choose production mode when:

- Multiple services share a single sidecar in the same Pod
- Compliance requires credentials never leave a dedicated container
- You want the sidecar to handle reconnects, retries, and broker quirks while
  your handler stays pure logic
- You upload blobs larger than 4 MiB and want the SDK's transparent chunked
  upload (introduced in v0.2.0)

Direct mode is documented in
[`../direct-mode/PATH_TO_PRODUCTION.md`](../direct-mode/PATH_TO_PRODUCTION.md).
Pick that one when you have one service per Pod and don't mind the SDK
holding credentials.

---

## Step 1: Local dev with the production-mode bundle

The production-mode tarball ships a working `docker-compose.yml` that brings
up RabbitMQ + Azurite + the sidecar + an example service. Run through
`QUICKSTART.md` until the example service answers commands and your handler
shape is wired up.

When that works, the production-mode runtime contract is established. Moving
to Kubyk only changes: who builds the image, who injects env vars, who mounts
the socket.

---

## Step 2: Build a Kubyk-ready service image

The customer-side contract is the same three files at repo root —
`version.yaml`, `Dockerfile`, `main.py` — but the Dockerfile installs the
**production-mode wheel** rather than the direct-mode wheel, and `main.py`
relies on `KBM_LEDSAS_MODE=production` being set at runtime.

```dockerfile
FROM python:3.11-slim
WORKDIR /app

ARG SDK_VERSION=0.2.0
COPY ledsas-sdk-production-v${SDK_VERSION}.tar.gz .
RUN tar -xzf ledsas-sdk-production-v${SDK_VERSION}.tar.gz && \
    pip install --no-cache-dir \
        ledsas-sdk-production-v${SDK_VERSION}/1-sdk/kbm_ledsas_sdk-${SDK_VERSION}-py3-none-any.whl && \
    rm -rf ledsas-sdk-production-v${SDK_VERSION}.tar.gz ledsas-sdk-production-v${SDK_VERSION}

COPY main.py .

RUN useradd -m appuser && chown -R appuser:appuser /app
USER appuser

CMD ["python", "main.py"]
```

The `main.py` is identical in shape to direct mode — `ServiceApp` and
`@app.handler` — but the SDK selects the UDS transport when
`KBM_LEDSAS_MODE=production` is set. No code change is required to switch
between modes.

---

## Step 3: Kubyk-side Pod composition

Kubyk MUST run the sidecar (`kbm-ledsas-agent`) and the customer service in
the **same Pod** so they share a filesystem and can communicate over UDS.
The reference Pod spec (one container per concern, shared `emptyDir` for the
socket):

```yaml
spec:
  terminationGracePeriodSeconds: 60
  volumes:
    - name: ledsas-socket
      emptyDir: {}
  containers:
    - name: ledsas-agent
      image: kbm-ledsas-agent:0.2.2
      env:
        - name: KBM_LEDSAS_SOCKET_PATH
          value: /run/kbm-ledsas/agent.sock
        - name: KBM_LEDSAS_RABBITMQ_URL
          valueFrom: { secretKeyRef: { name: ledsas-broker, key: amqps_url } }
        - name: KBM_LEDSAS_BLOB_CONN_STRING
          valueFrom: { secretKeyRef: { name: ledsas-blob, key: conn_string } }
        - name: KBM_LEDSAS_CONTAINER
          value: my-service-blobs
      volumeMounts:
        - { name: ledsas-socket, mountPath: /run/kbm-ledsas }
      livenessProbe:
        httpGet: { path: /livez, port: 8080 }   # sidecar health default
        periodSeconds: 10

    - name: my-service
      image: my-service:0.1.0-abc123
      env:
        - name: KBM_LEDSAS_MODE
          value: production
        - name: KBM_LEDSAS_SERVICE_NAME
          value: MyService
        - name: KBM_LEDSAS_TENANT
          value: acme
        - name: KBM_LEDSAS_SOCKET_PATH
          value: /run/kbm-ledsas/agent.sock
      volumeMounts:
        - { name: ledsas-socket, mountPath: /run/kbm-ledsas }
      livenessProbe:
        httpGet: { path: /livez, port: 8090 }   # SDK health on 8090
        periodSeconds: 10
```

Notes:

- Sidecar holds the broker + blob credentials; service container has neither.
  This is the entire compliance reason production mode exists.
- `emptyDir` for the socket means the socket exists only for the Pod
  lifetime; restart-on-failure recreates it cleanly.
- The sidecar listens on UDS plus its own loopback health server on 8080
  (sidecar default); the SDK in the service container listens on a
  separate loopback health server on 8090 (SDK default). Both ports are
  loopback-only inside the Pod network
  namespace.
- macOS users running locally may hit the AF_UNIX 104-char path limit; on
  Linux the limit is 108 chars. `/run/kbm-ledsas/agent.sock` (24 chars) is
  well within both.

---

## Step 4: Env vars the service container needs

Per the contract:

| Variable | Required | Notes |
|---|---|---|
| `KBM_LEDSAS_MODE` | Yes | Must be `production` |
| `KBM_LEDSAS_SERVICE_NAME` | Yes | Must match `ServiceApp(service_name=...)` |
| `KBM_LEDSAS_TENANT` | Recommended | Tenant prefix for AMQP topology |
| `KBM_LEDSAS_SOCKET_PATH` | Yes | Must match the sidecar's bind path |

The service container does NOT need `KBM_LEDSAS_RABBITMQ_URL` or
`KBM_LEDSAS_BLOB_CONN_STRING` — those go to the sidecar.

Optional (same defaults as direct mode):
`KBM_LEDSAS_LOG_LEVEL`, `KBM_LEDSAS_LOG_FORMAT`, `KBM_LEDSAS_HANDLER_TIMEOUT`,
`KBM_LEDSAS_MAX_RETRIES`, `KBM_LEDSAS_GENERIC_ERRORS`,
`KBM_LEDSAS_HEALTH_PORT`, `KBM_LEDSAS_HEALTH_HOST`,
`KBM_LEDSAS_MAX_PAYLOAD_BYTES`.

---

## Step 5: Health probes

The SDK in the service container and the sidecar each expose their own
health endpoints — Kubyk should probe **both**:

- Service container: `GET /livez` and `/ready` on `127.0.0.1:8090` (SDK default)
- Sidecar: `GET /livez` and `/ready` on `127.0.0.1:8080` (sidecar default; configure via the sidecar's `HEALTH_PORT` env var if you need to remap)

The sidecar's `/ready` aggregates: socket bound + AMQP connection up + blob
client healthy. The service `/ready` aggregates: socket connected to sidecar
+ subscriptions established + customer-provided readiness checks.

Set `terminationGracePeriodSeconds: 60` so SIGTERM-on-idle drain finishes
across both containers.

---

## Step 6: Chunked upload (v0.2.0)

Starting in v0.2.0, the SDK transparently uses chunked transfer over UDS for
uploads ≥ 4 MiB. No code change is needed. The sidecar maintains an upload
session for the duration of a single `upload_*` call (5-minute TTL); the SDK
splits the payload into 4 MiB chunks and reassembles on the sidecar side
before forwarding to Azure Blob.

The per-blob ceiling is 256 MiB in v0.2.0. The legacy 10 MiB JSON-RPC
per-message cap remains on the framing layer (chunks fit comfortably under
it).

---

## Step 7: Upgrading the SDK + sidecar

In production mode you bump **both** images:

1. Pull new `kbm_ledsas_sdk-v<X.Y.Z>-py3-none-any.whl` and bundle it in your
   service image (replacing the old wheel).
2. Pull the matching sidecar image (`kbm-ledsas-agent:<X.Y.Z>`) into your
   Pod spec.
3. SDK and sidecar versions MUST match within a minor — v0.2.x SDK with
   v0.2.x sidecar is fine; v0.2.x SDK with v0.1.x sidecar is unsupported.
   The CHANGELOG calls out wire-format compatibility windows; the
   `data_base64` → `data` transition (v0.1.7 → v0.1.8) and chunked upload
   methods (v0.2.0) are the recent examples.
4. Push, roll, watch readiness probes settle.

---

## What's NOT in this guide

- **Sidecar internals** — see the sidecar repo's `README.md` and the
  production-mode tarball's `1-sidecar/` directory.
- **Sidecar health server hardening** — partially deferred to ISSUE-005 in
  this project's issue backlog (`ServiceNameFilter`, Server-header strip on
  sidecar `/health` mirroring the SDK-side hardening already in v0.1.8).
- **Multi-service Pods** — multiple service containers sharing one sidecar
  is supported via independent UDS connections; each service container
  needs its own `KBM_LEDSAS_SERVICE_NAME` and reaches the sidecar over the
  same socket.

For anything not listed above, the canonical reference is
[`docs/dhf/kubyk-contract.md`](../../docs/dhf/kubyk-contract.md).
