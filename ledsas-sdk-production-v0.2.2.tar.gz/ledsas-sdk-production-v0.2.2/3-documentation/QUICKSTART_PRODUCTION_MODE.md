# Quick Start — Production Mode (UDS)

> Audience: a developer who has a LEDSAS service in mind and wants to
> wire it against a real `kbm-ledsas-agent` sidecar on a laptop before
> deploying to Kubernetes / Kubyk.
>
> Time budget: ~30 minutes.

Production mode means: your service uses `KBM_LEDSAS_MODE=production`,
which routes blob + AMQP operations through a Unix domain socket to
the `kbm-ledsas-agent` sidecar. The sidecar owns the real AMQP and
Azure Blob connections. The customer service holds no credentials.

For a laptop walkthrough using direct mode (no sidecar; SDK talks to
RabbitMQ + Azurite itself), see the **direct-mode** tarball instead.

---

## 1. Install the SDK + sidecar

```bash
cd ledsas-sdk-production-v0.2.0

# Virtual environment (required on PEP 668 systems — modern macOS / Ubuntu)
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip setuptools

# Install the SDK (your service code)
pip install 1-sdk/kbm_ledsas_sdk-0.2.0-py3-none-any.whl

# Install the sidecar (typically in its own venv or container, but
# you can co-install for a smoke test)
pip install 1-sidecar/kbm_ledsas_agent-0.2.0-py3-none-any.whl
```

> **Reproducible install** (regulated environments): use the lockfile
> at `1-sdk/requirements.lock.txt`:
> ```bash
> pip install -r 1-sdk/requirements.lock.txt
> pip install 1-sdk/kbm_ledsas_sdk-0.2.0-py3-none-any.whl
> ```

---

## 2. Bring up RabbitMQ + Azurite

The sidecar still needs a RabbitMQ instance and an Azure Blob endpoint
to talk to. For a laptop smoke test, reuse the direct-mode
docker-compose stack:

```bash
# From the direct-mode tarball (sibling to this one):
docker compose -f path/to/direct-mode/3-local-development/docker-compose.yml up -d

# Verify:
nc -z 127.0.0.1 5672 && echo "RabbitMQ up"
nc -z 127.0.0.1 10000 && echo "Azurite up"
```

---

## 3. Start the sidecar

```bash
export SOCKET_PATH=/tmp/ledsas-agent.sock
export SERVICE_NAME=my-service
export RABBITMQ_HOST=127.0.0.1
export RABBITMQ_USER=guest
export RABBITMQ_PASSWORD=guest
export BLOB_CONN_STRING="DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;"
export BLOB_CONTAINER=dev
export LOG_LEVEL=INFO

# Run the sidecar (in a separate terminal so it stays in the foreground).
# The wheel registers a console script entry point; this is the canonical invocation:
kbm-ledsas-agent

# Sidecar env-var note: the sidecar uses UNPREFIXED env vars (SOCKET_PATH,
# SERVICE_NAME, RABBITMQ_HOST, BLOB_CONN_STRING, etc.) while the SDK uses
# KBM_LEDSAS_-prefixed env vars. Don't mix the two namespaces.
```

You should see JSON log lines like:
```
{"timestamp":"...","level":"INFO","logger":"server.uds_server","message":"UDS server started","socket_path":"/tmp/ledsas-agent.sock"}
```

Verify the socket exists:
```bash
ls -la /tmp/ledsas-agent.sock
```

---

## 4. Run the example service

Open a second terminal and run the example handler:

```bash
source venv/bin/activate
export KBM_LEDSAS_MODE=production
export KBM_LEDSAS_SOCKET_PATH=/tmp/ledsas-agent.sock
export KBM_LEDSAS_SERVICE_NAME=my-service

python examples/uds_mode_example.py
```

The service logs (also JSON) should show a "subscribed" line, then
wait for commands.

---

## 5. Send a command through the sidecar

In a third terminal, publish a test command via `rabbitmqadmin` (ships
with the RabbitMQ management image) or any AMQP client:

```bash
docker exec -it ledsas-rabbitmq-direct \
  rabbitmqadmin publish \
    routing_key=cmd.my-service.v1 \
    payload='{"envelope":{"schema_version":"1.0","name":"echo","message_id":"00000000-0000-0000-0000-000000000001","correlation_id":"00000000-0000-0000-0000-000000000002","trace_id":"00000000-0000-0000-0000-000000000003","idempotency_key":"00000000-0000-0000-0000-000000000004","tenant":"t","source":"client","type":"command","reply_to":"reply.exchange","sent_at":"2026-05-28T12:00:00Z","message_version":"1.0"},"payload":{"text":"hello"}}'
```

The service should log handling the message and ACK it through the
sidecar. The sidecar logs the AMQP ack.

---

## 6. Where to next?

- **Production deploy:** see
  [`../2-kubernetes-deployment/README.md`](../2-kubernetes-deployment/README.md)
  for the K8s manifest skeleton.
- **API surface:** see
  [`SDK_API_REFERENCE.md`](SDK_API_REFERENCE.md) for `ServiceApp`,
  `ExecutionContext`, blob operations, error mapping.
- **Sidecar operation:** see
  [`../2-kubernetes-deployment/sidecar-startup.md`](../2-kubernetes-deployment/sidecar-startup.md).

---

## Common Issues

| Symptom | Cause / Fix |
|---------|-------------|
| Service log: `Sidecar unreachable` | Sidecar isn't running or `KBM_LEDSAS_SOCKET_PATH` doesn't match `SOCKET_PATH`. |
| Service log: `INVALID_PARAMS data must be a non-empty base64 string` on `upload_bytes` | SDK and sidecar versions incompatible. v0.1.8 SDK + v0.1.8 sidecar (this release) works; v0.1.8 sidecar also accepts SDKs ≤ v0.1.7 for one transition window. See README compatibility table. |
| Sidecar log: `Connection to RabbitMQ refused` | RabbitMQ isn't reachable from inside the sidecar's network namespace. Check `RABBITMQ_HOST` (use `host.docker.internal` from inside Docker on macOS). |
| Sidecar log: `cleartext AMQP refused` | The sidecar refuses `amqp://` to non-loopback hosts. Either use `amqps://` or, for a local-network smoke test only, set `KBM_LEDSAS_ALLOW_INSECURE_AMQP=1`. |
| SIGTERM doesn't shut down cleanly | The sidecar drains in-flight handlers before exiting. Increase `terminationGracePeriodSeconds` in your K8s spec. |
