#!/usr/bin/env python3
"""
LEDSAS SDK - UDS-mode Example Service (v0.2.0)

A minimal LEDSAS service running in production mode (UDS transport).

Architecture:
    Service --[UDS JSON-RPC]--> kbm-ledsas-agent --[AMQP]--> RabbitMQ
                                                --[HTTPS]--> Azure Blob

Prerequisites:
    - kbm-ledsas-agent sidecar running (see QUICKSTART_PRODUCTION_MODE.md)
    - The sidecar's SOCKET_PATH matches this process's KBM_LEDSAS_SOCKET_PATH
    - kbm-ledsas-sdk installed in this process's venv

Run (from the package root, venv active, sidecar up):

    export KBM_LEDSAS_MODE=production
    export KBM_LEDSAS_SOCKET_PATH=/tmp/ledsas-agent.sock
    export KBM_LEDSAS_SERVICE_NAME=echo-service

    # Optional: KBM_LEDSAS_TENANT must match the sidecar's TENANT
    # export KBM_LEDSAS_TENANT=acme

    # Optional tuning (the sidecar holds the retry budget; SDK only
    # holds the handler timeout):
    export KBM_LEDSAS_HANDLER_TIMEOUT=1800
    export KBM_LEDSAS_GENERIC_ERRORS=false

    # SDK-side health endpoint (sidecar has its own on 8080):
    export KBM_LEDSAS_HEALTH_PORT=8090

    python 3-documentation/examples/uds_mode_example.py

    # In another shell, probe the SDK-side health endpoint:
    curl -s http://127.0.0.1:8090/health
    curl -s http://127.0.0.1:8090/ready

    # And the sidecar's:
    curl -s http://127.0.0.1:8080/livez
    curl -s http://127.0.0.1:8080/readyz

Behavior note:
    The handler code is *exactly* the same as it would be in direct
    mode — the SDK's transport layer abstracts away whether ctx.blob.*
    calls hit Azure directly or go through the sidecar.
"""

import logging
from kbm_ledsas_sdk import ServiceApp, errors


# Configure your service's own logging. The SDK configures
# kbm_ledsas_sdk.* from KBM_LEDSAS_LOG_LEVEL / KBM_LEDSAS_LOG_FORMAT.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


# Service name MUST match what the sidecar advertises (sidecar's
# SERVICE_NAME env var). The sidecar binds its AMQP topology to this
# name; a mismatch means the SDK's commands never arrive.
app = ServiceApp(service_name="echo-service")


@app.handler("Echo")
async def handle_echo(ctx, req: dict) -> dict:
    """
    Trivial echo handler — prove the wire is alive.

    Demonstrates:
      - ctx.message_id, ctx.correlation_id, ctx.deadline
      - errors.Permanent with a user_message (caller-visible)
      - blob ops through the sidecar (commented out — uncomment to test)
    """
    logger.info(
        "handling Echo",
        extra={
            "message_id": ctx.message_id,
            "correlation_id": ctx.correlation_id,
            "deadline": str(ctx.deadline) if ctx.deadline else None,
        },
    )

    # Validate input shape — caller's error, not transient.
    if not isinstance(req, dict) or "text" not in req:
        raise errors.Permanent(
            "Echo payload missing 'text' field",
            user_message="Echo requires a 'text' field in the payload.",
        )

    text = req["text"]

    # Demonstrate that ctx.blob.* works exactly as in direct mode —
    # uncomment to round-trip a blob through the sidecar:
    #
    # uri = await ctx.blob.upload_text(
    #     container="echo-out",
    #     text=text,
    #     path=f"echo/{ctx.message_id}.txt",
    #     overwrite=True,
    # )
    # logger.info("uploaded echo to %s", uri.uri)

    return {
        "echo": text,
        "echoed_at": ctx.message_id,  # demonstrates that the SDK exposes envelope context
    }


@app.handler("FailRetryable")
async def handle_fail_retryable(ctx, req: dict) -> dict:
    """Demonstrate a transient failure — sidecar will requeue per its retry budget."""
    raise errors.Retryable(
        "Simulated transient failure",
        user_message="The service is briefly unavailable; please retry.",
    )


@app.handler("FailPermanent")
async def handle_fail_permanent(ctx, req: dict) -> dict:
    """Demonstrate a non-retryable failure — sidecar will DLQ the message."""
    raise errors.Permanent(
        "Simulated permanent failure",
        user_message="The request cannot be processed.",
    )


if __name__ == "__main__":
    # ServiceApp.run() blocks until SIGTERM/SIGINT. Handler exceptions
    # become "response" envelopes addressed to envelope.reply_to.
    app.run()
