# LEDSAS SDK - Direct Mode Developer Package

**Version:** 0.1.5-1
**Package Type:** Direct Mode (Local Development)

---

## What is This Package?

This is a **streamlined developer package** for the LEDSAS SDK, designed to help you:

- Get started quickly with **Direct Mode** (local development)
- Build and test your microservice locally using RabbitMQ + Azure Blob Storage emulation
- Validate your service implementation before deploying to Production

**Not Included:** Production mode deployment (sidecar, Kubernetes, security hardening). You'll receive the full package when ready for Production.

---

## Quick Start (5 Minutes)

### Prerequisites

- **Python 3.11+** installed
- **Docker** and Docker Compose installed
- Basic knowledge of Python and async programming

### Step 1: Install SDK

```bash
cd 1-sdk
pip install kbm_ledsas_sdk-0.1.5-py3-none-any.whl
```

### Step 2: Start Local Environment

```bash
cd ../3-local-development
docker compose up -d
```

This starts:
- **RabbitMQ** (message queue) - `localhost:5672`
- **Azurite** (Azure Storage emulator) - `localhost:10000`

### Step 3: Run Example

```bash
cd ../2-documentation/examples
export KBM_LEDSAS_MODE=direct
export KBM_LEDSAS_RABBITMQ_URL=amqp://guest:guest@localhost:5672/
export KBM_LEDSAS_BLOB_CONN_STRING=DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;

python direct_mode_example.py
```

---

## Next Steps

1. **Read the Quick Start Guide**
   See `2-documentation/QUICKSTART_DIRECT_MODE.md` for detailed setup instructions

2. **Review SDK API Reference**
   See `2-documentation/SDK_API_REFERENCE.md` for complete API documentation

3. **Study Examples**
   - `2-documentation/examples/direct_mode_example.py` - Complete working example
   - `2-documentation/examples/simple_csv_processor.py` - Minimal example

4. **Build Your Service**
   Use the POC source code as a reference: `4-reference/poc-service-source-0.1.5.tar.gz`

---

## Package Contents

```
ledsas-sdk-direct-v0.1.5-1/
├── README.md                      # This file
│
├── 1-sdk/                         # SDK wheel and dependencies
│   ├── kbm_ledsas_sdk-0.1.5-py3-none-any.whl
│   ├── requirements.txt
│   └── checksums.txt
│
├── 2-documentation/               # Direct Mode documentation
│   ├── QUICKSTART_DIRECT_MODE.md
│   ├── SDK_API_REFERENCE.md
│   └── examples/
│       ├── direct_mode_example.py
│       └── simple_csv_processor.py
│
├── 3-local-development/           # Docker Compose for local testing
│   ├── docker-compose.yml
│   ├── .env.example
│   └── README.md
│
├── 4-reference/                   # POC service source code
│   └── poc-service-source-0.1.5.tar.gz
│
└── 5-legal/                       # License and compliance
    ├── LICENSE.txt
    ├── THIRD_PARTY_NOTICES.txt
    └── COMPLIANCE.md
```

---

## Direct Mode vs Production Mode

### Direct Mode (This Package)

- **Purpose:** Local development and testing
- **Security:** Microservice accesses RabbitMQ and Azure Blob Storage directly
- **Use Case:** Build and validate your service logic
- **Deployment:** Local Docker environment

### Production Mode (Full Package)

- **Purpose:** Production deployment
- **Security:** Microservice communicates via sidecar (no direct credentials)
- **Use Case:** Deploy to Kubernetes with security hardening
- **Deployment:** Kubernetes with Istio service mesh

**When you're ready for Production, request the full package.**

---

## Support

For questions or issues:

1. Check `2-documentation/QUICKSTART_DIRECT_MODE.md` for troubleshooting
2. Review SDK API Reference for API details
3. Contact KeborMed support for assistance

---

## License

See `5-legal/LICENSE.txt` for licensing information.

---

**Ready to start?** Go to `2-documentation/QUICKSTART_DIRECT_MODE.md` for step-by-step instructions!
