# Changelog

## v0.2.2 — 2026-05-28

Matched-pair version bump only. **No SDK or sidecar functional change.** The
v0.2.2 work landed in the direct-mode distribution (bundled `5-templates/` demo
repos + cardiac-echo pydicom handler); the production tarball stays demo-free
this round. SDK + sidecar versions are bumped together to keep the production
compatibility matrix on a single coherent version line.

### Versions

- **SDK 0.2.1 → 0.2.2.** No functional change.
- **Sidecar 0.2.1 → 0.2.2.** No functional change.

Production customers do not need to upgrade from 0.2.1.

---

## v0.2.1 — 2026-05-28

### Sidecar hardening (ISSUE-005 resolved)

Mirrors the SDK v0.1.8 hardening points that have natural analogs on the
sidecar side. Pure operator-facing improvements; no SDK API change.

- **`SidecarNameFilter` on every sidecar log record.** When `SERVICE_NAME`
  is set, every record emitted by `kbm-ledsas-agent.*` and its child
  loggers now carries a `service_name` field. Customer operators reading
  mixed SDK + sidecar log streams can now correlate by a single field —
  was previously inconsistent (SDK records had it, sidecar records
  didn't). Source-of-truth: `kbm-ledsas-agent/telemetry/logging.py:setup_logging`.
- **`Server` header strip on sidecar `/health` + `/ready`.** Aiohttp's
  default `Server: Python/3.11 aiohttp/X.Y.Z` header is now removed
  from every response (200, 404, 405) via an `on_response_prepare`
  hook — same pattern as the SDK's health server. Closes the runtime-stack
  fingerprint surface.
- **JSON 404 / 405 responses on the sidecar health server.** Default
  aiohttp 404/405 bodies are plaintext; an ops dashboard that JSON-decodes
  every probe response would fall over on a stray `HEAD /admin`. Now
  uniform JSON across all status codes.

### Versions

- **SDK 0.2.0 → 0.2.1.** No SDK functional change; version bump only for
  matched-pair convention with the sidecar.
- **Sidecar 0.2.0 → 0.2.1.**

### Compatibility

- v0.2.1 SDK + v0.2.1 sidecar: full feature set (matched pair).
- v0.2.0 SDK + v0.2.1 sidecar: works unchanged (chunked upload, fallback,
  all v0.2.0 paths intact).
- v0.2.1 SDK + v0.2.0 sidecar: works unchanged. Customer logs lose the
  consolidated `service_name` field on the sidecar half — upgrade the
  sidecar for log-correlation parity.

### Tests added

- `kbm-ledsas-agent/tests/unit/test_health_hardening.py` (5 tests:
  Server-header stripped on 200/404/405; 404 JSON body shape;
  405 JSON body with allowed methods).
- `kbm-ledsas-agent/tests/unit/test_sidecar_name_filter.py` (5 tests:
  filter behavior; formatter emits service_name when present + omits
  when absent; `setup_logging(service_name=...)` wires the filter
  end-to-end; `setup_logging()` without service_name skips it).

Sidecar test count: 286 → 296.

---

## v0.2.0 — 2026-05-28

### New

- **Chunked upload over UDS (M3):** `upload_bytes`, `upload_text`,
  `upload_json` (and `upload_stream`, which routes through `upload_bytes`)
  now transparently use chunked transfer for payloads at or above
  4 MiB, lifting the practical ~7 MiB cap that the sidecar's 10 MiB
  JSON-RPC per-message framing limit imposed on single-RPC uploads.
  Max single-blob upload is now **256 MiB**.

  Three new RPC methods are wired across the SDK↔sidecar boundary:

  - `blob.upload_init(container, path, total_size, sha256, overwrite, chunk_size)`
    → `{session_id}`
  - `blob.upload_chunk(session_id, chunk_index, data)`
    → `{received_bytes, next_chunk_index}`
  - `blob.upload_complete(session_id)`
    → `{uri, etag, version_id, size}`

  Session ids are opaque (`upl_` + 32 random hex). Sessions are
  in-memory in the sidecar and scoped to a single UDS connection.
  TTL is 300 seconds; the sidecar evicts past-deadline sessions on
  the next operation.
- **Legacy `data_base64` parameter accepted on `blob.upload_chunk`**
  for one release as a transition window, mirroring the
  `blob.upload` shim opened in v0.1.8. Drop in v0.3.x.

### Changed

- **SDK version 0.1.8 → 0.2.0.**
- **Sidecar version 0.1.8 → 0.2.0.** Both wheels in this tarball
  carry the matching version. The sidecar's
  `kbm-ledsas-agent/server/upload_session.py` houses the new
  `UploadSession` / `UploadSessionStore` types.

### Constraints (sidecar)

- `total_size` ≤ 256 MiB
- `chunk_size` ≤ 4 MiB
- `sha256` if given must be 64-character lowercase hex
- Chunks must arrive in strict index order (out-of-order is rejected
  with `INVALID_PARAMS`)
- Cumulative bytes received must not exceed declared `total_size`
- At `blob.upload_complete`, if `sha256` was given, the sidecar
  recomputes it over the assembled buffer and rejects a mismatch

### Compatibility matrix (updated)

| SDK version | Sidecar version | Compatible? |
|-------------|-----------------|-------------|
| 0.2.0       | 0.2.0           | yes (matched pair — this release) |
| 0.2.0       | 0.1.8           | yes for payloads ≤ 7 MiB — the SDK catches the older sidecar's `METHOD_NOT_FOUND` on `blob.upload_init` and falls back to single-RPC `blob.upload` (with a WARNING log). Payloads > 7 MiB (where the base64-inflated body would overflow the 10 MiB JSON-RPC cap) raise a clear "Upgrade the sidecar to v0.2.0" error. |
| 0.1.8       | 0.2.0           | yes — SDK never invokes chunked methods; sidecar still accepts the canonical `data` key on `blob.upload`. |
| ≤ 0.1.7     | 0.2.0           | yes — sidecar still accepts legacy `data_base64` for one release. |

### Notes

- All v0.1.8 hardening points (envelope validation, security
  defenses, health-server fingerprint scrub, lockfile-portability
  build gates, etc.) carry over to v0.2.0 unchanged.
- Contract tests in
  `kbm_ledsas_sdk/tests/contracts/test_chunked_upload_contract.py`
  lock the three new RPC methods' wire shape (SDK ⊆ sidecar accepted,
  SDK ⊇ sidecar required, response-shape parity, legacy-key
  acceptance).

---

## v0.1.8 — 2026-05-28

> **Note:** the previous v0.1.8 release notes are preserved here for
> auditability and because customers upgrading from a prior production
> bundle reach v0.2.0 through this release. The current shipping bundle
> is v0.2.0 (see entry above).

This is the production-mode counterpart to direct-mode v0.1.8. The
SDK wheel inside this tarball is the same artifact that ships in the
direct-mode tarball at v0.1.8 — except production keeps the UDS
transport modules (`uds_client.py`, `jsonrpc.py`, `uds_operations.py`,
`_internal_factory.py`, `_internal_mode.py`) that direct strips. The
wheel SHA inside this tarball therefore differs from the direct one;
parity is at the **source-version** and **hardening-point** level,
not the wheel-binary-hash level.

The sidecar wheel (`kbm-ledsas-agent`) ships at v0.1.8, bumped from
v0.1.1 for cohesion with the SDK version. The sidecar code itself
received the UDS field-symmetry fix below and no other behavioural
changes. Two additional sidecar hardening points (operator log
filtering, health-server fingerprint scrub) are tracked as
[`ISSUE-005`](https://github.com/KeborMed/kbm.custom-local-ds.sdks/blob/main/docs/issues/ISSUE-005.md)
for a follow-up release.

### Production-mode-specific fixes

- **`blob.upload` field name aligned: SDK `data_base64` → canonical
  `data`.** Pre-v0.1.8 the SDK sent `data_base64` and the sidecar
  read `data`, so every UDS-mode `upload_bytes` against a real
  sidecar returned `INVALID_PARAMS`. The bug lived undetected
  through 11 cold-review cycles (TASK-013 → TASK-024) because the
  production tarball wasn't re-cut after the SDK changes and the
  existing mock-transport tests never serialized to JSON. The fix:
  - SDK sends the canonical key `data`.
  - Sidecar accepts BOTH `data` and `data_base64` for one release as
    a transition window — SDKs ≤ v0.1.7 paired with this v0.1.8
    sidecar still work. The sidecar logs DEBUG when the legacy key
    is used; drop the compat in v0.2.x.
  - Contract test (`kbm_ledsas_sdk/tests/contracts/test_rpc_field_symmetry.py`,
    32 parameterized cases + 3 standalone) locks the symmetry
    property across all 10 RPC methods so the bug class can't recur.
- **`blob.upload` overwrite parameter is honoured end-to-end.**
  Pre-fix, the SDK passed `overwrite=True/False` over RPC but the
  sidecar handler silently dropped it and the inner Azure call
  hardcoded `overwrite=False`. Customer code calling
  `upload_bytes(..., overwrite=True)` in UDS mode raised at the
  Azure layer (existing-blob rejection) instead of overwriting. Now
  the sidecar reads `overwrite`, validates it as boolean, and
  forwards it through `client.upload_blob(overwrite=...)`.

### Sidecar-side changes

- **Sidecar version bumped 0.1.1 → 0.1.8** for cohesion with the
  customer-facing SDK version. No new sidecar features; the bump
  documents "this sidecar was validated against SDK 0.1.8 and ships
  the UDS field-symmetry fix above". Older sidecars don't read the
  canonical `data` key — pair the SDK with this sidecar (or
  upgrade to a later sidecar) for v0.1.8 customer-facing behaviour.

### SDK-side hardening (same wheel as direct v0.1.8)

The SDK wheel inside `1-sdk/` carries every TASK-018 → TASK-024
hardening point already documented in the direct-mode CHANGELOG.
Summary (see direct-mode CHANGELOG for full per-point detail):

#### Wire format & validation

- Status messages now carry `envelope.type="status"` (was reusing
  the command envelope).
- `reply_to` constrained to URL-safe characters, max 127 chars.
- `KBM_LEDSAS_SERVICE_NAME` + `KBM_LEDSAS_TENANT` combined-length cap
  at config-load (refuses topology names that overflow the AMQP
  127-byte protocol limit).
- `message_id` / `correlation_id` accept mixed-case UUIDs (normalized
  to lowercase internally).
- `envelope.type` Literal trimmed to `command` / `response` / `status`
  (was 4 values, the unused `error` removed).
- `BlobRef` rejects control characters (`< 0x20`, `0x7f`) in URIs at
  parse time.
- `KBM_LEDSAS_HANDLER_TIMEOUT` capped at 86 400 s,
  `KBM_LEDSAS_MAX_PAYLOAD_BYTES` capped at 256 MiB.

#### Error handling

- Cleaner config-error output for invalid `KBM_LEDSAS_MODE`.
- Deadline-already-past returns `{"code": "DeadlineExceeded",
  "retryable": false}` (was being mis-classified as retryable
  `Timeout`).
- `DeadlineExceeded` and `Timeout` carry distinct caller-visible
  messages reflecting their different retry semantics.
- `errors.SDKError` is the documented catch-all base for all three
  concrete error types.

#### Logging

- `ServiceNameFilter` attached at handler level — every SDK log
  record from every child logger (`kbm_ledsas_sdk.amqp.*`,
  `kbm_ledsas_sdk.blob.*`, etc.) carries `service_name`.
- All `logger.error/warning(f"...: {e}")` in `runtime/handler.py`
  refactored to use `extra={"error_message": str(e)}` — text-format
  log viewers don't see ANSI/control bytes from exception messages.
- URL credential scrub `***:***@` on any AMQP URL in log lines.

#### Health endpoints

- `Server: Python/aiohttp/X.Y.Z` header stripped from every SDK
  health response (200/404/405). Minor fingerprint reduction.
- 404 / 405 responses return JSON instead of HTML.
- New `ServiceApp.health_server_running` property exposes whether
  bind succeeded — queryable from outside the SDK.

#### Build & distribution

- `requirements.lock.txt` ships in `1-sdk/` for reproducible
  installs.
- Lockfile generation filters BOTH `pkg==X.Y.Z` and `pkg @ file://`
  forms of the SDK's own line (the second form had been leaking
  the build machine's absolute path through pre-TASK-022).
- Defense-in-depth scan fails the build if any `file://` URL or
  `/Users/` / `/home/` / `/root/` / `/opt/build` absolute path
  remains in the lockfile.
- New shared bash helpers in `scripts/_build_common.sh` factor out
  wheel-build, lockfile generation, leaked-path scan, and tarball
  + checksum steps. Both direct- and production-mode build scripts
  source it — drift between the two pipelines surfaces immediately
  via the `_build_common.sh sha256` line printed at the end of
  every build.

#### Internal-review labels

- All SEC-N / H-N / M-N / L-N internal review-tracking labels
  (TASK-013 → TASK-022) stripped from SDK source comments and
  packaging docs. None of these labels reach the customer-visible
  surface any more.

---

### Compatibility matrix (this release)

| SDK version | Sidecar version | Compatible? |
|-------------|-----------------|-------------|
| 0.1.8       | 0.1.8           | yes (matched pair — this release) |
| 0.1.8       | 0.1.1–0.1.7     | yes — sidecar accepts the legacy `data_base64` key on `blob.upload` for one release as a transition window |
| ≤ 0.1.7     | 0.1.8           | yes — SDK still sends `data_base64`; sidecar accepts both |
| ≤ 0.1.7     | ≤ 0.1.7         | **broken** — UDS-mode `upload_bytes` fails `INVALID_PARAMS`. Upgrade the SDK or the sidecar to v0.1.8 to recover. |

### Wheel-hash parity note

The SDK wheel inside this tarball does not have the same SHA as the
direct-mode v0.1.8 wheel. Direct-mode strips the UDS transport files
at build time; production keeps them. Parity in this release is at
the source-version (both built from the same `kbm_ledsas_sdk/` source
at SDK pyproject `version = "0.1.8"`) and hardening-point level (every
bullet above present in both wheels). The contract test in
`tests/contracts/` is the canonical proof that the wire shape
between the two wheels stays in sync.
