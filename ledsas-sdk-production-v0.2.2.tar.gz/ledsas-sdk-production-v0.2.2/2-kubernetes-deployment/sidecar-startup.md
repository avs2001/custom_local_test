# Sidecar Startup & Operation

The `kbm-ledsas-agent` sidecar process owns the AMQP + Azure
connections, terminates the UDS socket, and enforces topology /
payload-size / cleartext-AMQP policy.

## Required Environment Variables

| Variable | Purpose |
|----------|---------|
| `SERVICE_NAME` | Service identifier. 1..64 chars `[A-Za-z0-9._-]`. MUST match the SDK's `KBM_LEDSAS_SERVICE_NAME`. |
| `RABBITMQ_HOST` | RabbitMQ host. |
| `RABBITMQ_USER` | RabbitMQ username. |
| `RABBITMQ_PASSWORD` | RabbitMQ password. |
| `BLOB_CONN_STRING` | Azure Blob Storage connection string. Required (workload-identity support is on the roadmap). |

## Optional Environment Variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `SOCKET_PATH` | `/run/kbm-ledsas/agent.sock` | UDS socket path. MUST match SDK's `KBM_LEDSAS_SOCKET_PATH`. |
| `RABBITMQ_PORT` | `5672` | RabbitMQ port. |
| `RABBITMQ_VHOST` | `/` | RabbitMQ vhost. |
| `TENANT` | (none) | Tenant prefix. MUST match SDK's `KBM_LEDSAS_TENANT`. |
| `BLOB_CONTAINER` | `dev` | Default blob container. |
| `PREFETCH` | `10` | AMQP prefetch count. |
| `MAX_INLINE_BYTES` | `65536` | Threshold above which payloads must be stored in blob (referenced by URI in the AMQP envelope) rather than inlined. |
| `MAX_RETRY_ATTEMPTS` | `5` | Sidecar AMQP/Azure retry budget. |
| `LOG_LEVEL` | `INFO` | One of DEBUG/INFO/WARNING/ERROR. |
| `METRICS_PORT` | `9090` | Prometheus metrics port. |
| `HEALTH_PORT` | `8080` | HTTP health endpoint port. |

## Health Endpoints (HTTP, port `HEALTH_PORT`)

| Path | Purpose |
|------|---------|
| `/health` | Aggregate liveness + readiness (200 if all good, 503 otherwise). |
| `/livez` | K8s liveness probe — does the process respond? |
| `/readyz` | K8s readiness probe — AMQP + UDS server up? |
| `/ready` | Same as `/readyz`, kept for older config. |

Responses are JSON. The `Server` HTTP header is stripped from every
response (no `Python/3.11 aiohttp/X.Y.Z` leak).

## Signal Handling

| Signal | Behavior |
|--------|----------|
| `SIGTERM` | Begin graceful shutdown: stop accepting new commands, drain in-flight (up to grace period), close AMQP, close UDS, exit 0. Typical exit time is under 3 seconds when idle; ~150ms in the v0.1.8 customer-sim baseline. |
| `SIGINT` | Same as `SIGTERM`. |
| `SIGHUP` | Reserved (currently treated as terminate). |

Set `terminationGracePeriodSeconds: 60` in your K8s spec to give
long-running handlers room to finish.

## Logging

Structured JSON to stdout. Each record includes:

- `timestamp` (ISO-8601 UTC)
- `level`
- `logger`
- `message`
- (optional) `service_name`, `correlation_id`, `message_id`,
  `request_id`

Credentials are scrubbed: any AMQP URL appearing in a log line has its
user/password replaced with `***:***@`.

## Health-Check Cheat Sheet

```bash
# After bringing the Pod up:
kubectl exec -it your-pod -c ledsas-agent -- curl -s http://localhost:8080/livez
kubectl exec -it your-pod -c ledsas-agent -- curl -s http://localhost:8080/readyz

# If readyz returns 503, check the agent logs for AMQP / blob errors:
kubectl logs your-pod -c ledsas-agent --tail=100
```

## Failure Modes Customers See in Their Service Logs

| Symptom in your service log | What it means |
|-----------------------------|---------------|
| `Sidecar unreachable` (UDS connect error) | Sidecar container hasn't started, crashed, or `SOCKET_PATH` is wrong. Check the sidecar's readiness probe. |
| `INVALID_PARAMS data must be a non-empty base64 string` | Field-shape mismatch; usually means the SDK and sidecar are pinned to incompatible majors. See `README.md` compatibility table. |
| `DeadlineExceeded` (non-retryable) | Command arrived after its `envelope.deadline`. Re-publish with a fresh deadline; do not retry the same envelope. |
| `Timeout` (retryable) | Handler exceeded the in-process timeout. Increase your timeout setting or speed up the handler. |
