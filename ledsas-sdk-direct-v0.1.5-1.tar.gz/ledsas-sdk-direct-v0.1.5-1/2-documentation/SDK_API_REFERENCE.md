# LEDSAS SDK API Reference v0.1.5

Complete reference for all 20 SDK APIs implemented in kbm-ledsas-sdk v0.1.5.

---

## Environment Variables *(New in v0.1.5)*

Configure SDK behavior via environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `KBM_LEDSAS_MODE` | (production) | `direct` for local dev, omit for production |
| `KBM_LEDSAS_SERVICE_NAME` | Required | Service name for queue binding |
| `KBM_LEDSAS_RABBITMQ_URL` | Required (direct) | RabbitMQ connection URL |
| `KBM_LEDSAS_BLOB_CONN_STRING` | Required (direct) | Azure Blob connection string |
| `KBM_LEDSAS_CONTAINER` | `dev` | Default blob container |
| `KBM_LEDSAS_PREFETCH` | `10` | AMQP message prefetch count |
| `KBM_LEDSAS_CONCURRENCY` | `4` | Max concurrent handlers |
| `KBM_LEDSAS_LOG_LEVEL` | `INFO` | Logging level |
| `KBM_LEDSAS_LOG_FORMAT` | `json` | Log format (json/text) |
| **`KBM_LEDSAS_HANDLER_TIMEOUT`** | `1800` | **Handler timeout in seconds (0=disabled)** |
| **`KBM_LEDSAS_MAX_RETRIES`** | `3` | **Max retry attempts for retryable errors** |
| **`KBM_LEDSAS_GENERIC_ERRORS`** | `false` | **Return generic error messages (hide details)** |

### New Configuration Options (v0.1.5)

**Handler Timeout** (`KBM_LEDSAS_HANDLER_TIMEOUT`):
- Default: 1800 seconds (30 minutes)
- Set to `0` to disable timeout enforcement
- Handlers exceeding this duration are automatically cancelled

**Max Retries** (`KBM_LEDSAS_MAX_RETRIES`):
- Default: 3 retry attempts
- Applies to `Retryable` errors only
- After max retries, message goes to DLQ

**Generic Errors** (`KBM_LEDSAS_GENERIC_ERRORS`):
- Default: `false` (show detailed error messages)
- Set to `true` for production to hide internal error details
- Custom `user_message` overrides generic messages

---

## Message Format

The SDK expects incoming messages to follow a specific structure with an `envelope` and `payload`.

### Command Message Structure

```json
{
  "envelope": {
    "schema_version": "1.0",
    "type": "command",
    "name": "ProcessData",
    "message_version": "1.0",
    "message_id": "550e8400-e29b-41d4-a716-446655440000",
    "correlation_id": "123e4567-e89b-12d3-a456-426614174000",
    "idempotency_key": "unique-operation-key",
    "sent_at": "2025-12-02T10:30:00Z",
    "trace_id": "abc123-trace-id",
    "reply_to": "response.exchange.name",
    "deadline": "2025-12-02T10:35:00Z",
    "priority": 5
  },
  "payload": {
    "your_field": "your_data",
    "another_field": 123
  }
}
```

### Envelope Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `schema_version` | string | Yes | Schema version (use "1.0") |
| `type` | string | Yes | Message type: "command", "response", "status", "error" |
| `name` | string | Yes | Command name (e.g., "ProcessData") |
| `message_version` | string | Yes | Message schema version (e.g., "1.0") |
| `message_id` | string | Yes | Unique message identifier (UUID) |
| `correlation_id` | string | Yes | Correlation ID for tracking related messages |
| `idempotency_key` | string | Yes | Key for idempotent processing |
| `sent_at` | string | Yes | ISO8601 timestamp when message was sent |
| `trace_id` | string | Yes | Distributed tracing ID |
| `reply_to` | string | No | Exchange/queue name for responses (optional) |
| `deadline` | string | No | ISO8601 deadline for processing |
| `priority` | int | No | Message priority (higher = more urgent) |
| `job_id` | string | No | Business-level job identifier *(New in v0.1.5)* |

### Payload

The `payload` field contains your actual request data. This is what gets passed to your handler as the `req` parameter:

```python
@app.handler("ProcessData")  # Must match envelope.name in message
async def handle(ctx, req: dict):
    # req == the "payload" from the message
    your_field = req.get("your_field")  # "your_data"
    another_field = req.get("another_field")  # 123
```

### AMQP Topology

The SDK automatically creates this topology based on `service_name`:

| Component | Name Pattern | Type | Description |
|-----------|--------------|------|-------------|
| Command Exchange | `cmd.{service_name}.v1` | TOPIC | Receives incoming commands |
| Command Queue | `queue.{service_name}.v1` | - | Service consumes from here |
| DLQ Exchange | `dlq.{service_name}.v1` | TOPIC | Failed message routing |
| DLQ Queue | `dlq.queue.{service_name}.v1` | - | Stores failed messages |

**Example:** For `ServiceApp(service_name="csv-processor")`:
- Command exchange: `cmd.csv-processor.v1`
- Command queue: `queue.csv-processor.v1`

### Sending Messages to a Service

To send messages to a LEDSAS service, publish to its command exchange with routing key `#`:

```python
import pika
import json
import uuid
from datetime import datetime, timezone

# Connect to RabbitMQ
connection = pika.BlockingConnection(pika.URLParameters("amqp://guest:guest@localhost:5672/"))
channel = connection.channel()

# Build message
message = {
    "envelope": {
        "schema_version": "1.0",
        "type": "command",
        "name": "ProcessData",  # Must match @app.handler("ProcessData")
        "message_version": "1.0",
        "message_id": str(uuid.uuid4()),
        "correlation_id": str(uuid.uuid4()),
        "idempotency_key": str(uuid.uuid4()),
        "sent_at": datetime.now(timezone.utc).isoformat(),
        "trace_id": str(uuid.uuid4())
    },
    "payload": {
        "input_uri": "azblob://data/input.csv"
    }
}

# Publish to service's command exchange
channel.basic_publish(
    exchange="cmd.csv-processor.v1",  # cmd.{service_name}.v1
    routing_key="#",                   # Use "#" for TOPIC exchange
    body=json.dumps(message),
    properties=pika.BasicProperties(content_type="application/json")
)

connection.close()
```

**Key Points:**
- Exchange: `cmd.{service_name}.v1` (TOPIC type)
- Routing key: `#` (matches all)
- `envelope.name` MUST match the handler's command name (e.g., `@app.handler("ProcessData")`)

---

## ExecutionContext (9 APIs)

The `ExecutionContext` is passed to every handler function and provides access to message metadata, blob operations, and status reporting.

### Properties (6)

#### `envelope.message_id: str`
Unique identifier for this specific message (UUID format). Accessed via `ctx.envelope.message_id`.

```python
ctx.logger.info("Processing", message_id=ctx.envelope.message_id)
```

####  `correlation_id: str`
Correlation ID for tracking related messages across system.

```python
# Use for distributed tracing
ctx.logger.info("Step complete", correlation_id=ctx.correlation_id)
```

#### `idempotency_key: str`
Key for ensuring idempotent processing (typically same as correlation_id).

```python
# Use to generate stable output paths
output_path = f"results/{ctx.idempotency_key}.json"
```

#### `deadline: Optional[datetime]`
Processing deadline (UTC datetime). Handler should finish before this time.

```python
from datetime import datetime, timezone, timedelta

if ctx.deadline and datetime.now(timezone.utc) > ctx.deadline - timedelta(seconds=5):
    raise errors.DeadlineExceeded("Not enough time to process")
```

#### `job_id: Optional[str]` *(New in v0.1.5)*
Business-level job identifier set by the orchestrator. Unlike `correlation_id` (SDK-controlled), `job_id` is set by the caller and echoed in all responses for workflow tracking.

```python
@app.handler("ProcessBatch")
async def handle(ctx, req: dict) -> dict:
    # Log with job_id for batch correlation
    if ctx.job_id:
        ctx.logger.info("Processing job", job_id=ctx.job_id)

    # Include in response for tracking
    return {
        "status": "success",
        "job_id": ctx.job_id  # Optional: echo back for caller
    }
```

**Use Cases:**
- Tracking batch job progress across multiple commands
- Correlating with external job/workflow systems
- Audit logging for business workflows
- Grouping related commands in observability tools

**Note:** This field is **OPTIONAL** and **BACKWARDS COMPATIBLE**. Existing services without job_id handling will continue to work. The job_id is automatically echoed in status updates, responses, and error messages.

### Methods (1)

#### `emit_status(stage: str, progress: float, note: str = "") -> None`
Report processing status back to orchestrator.

**Parameters:**
- `stage` (str): Current processing stage (e.g., "downloading", "processing", "uploading")
- `progress` (float): Completion percentage (0.0 to 1.0)
- `note` (str, optional): Human-readable status message

**Example:**
```python
await ctx.emit_status("downloading", 0.0, "Starting download")
await ctx.emit_status("processing", 0.5, "Halfway through CSV rows")
await ctx.emit_status("done", 1.0, "Processing complete")
```

### Objects (2)

#### `envelope: Envelope`
Complete LEDSAS message envelope with all metadata.

**Useful Properties:**
```python
ctx.envelope.name           # Message name (e.g., "ProcessData")
ctx.envelope.message_version # Message schema version
ctx.envelope.sent_at        # When message was sent
ctx.envelope.trace_id       # Distributed tracing ID
```

#### `logger: StructuredLogger`
Structured logging interface with context auto-injection.

**Usage:**
```python
ctx.logger.info("Processing started", extra_field="value")
ctx.logger.warning("Slow operation", duration_ms=1500)
ctx.logger.error("Failed to parse", error=str(ex))
```

All log entries automatically include `correlation_id`, `message_id`, and `trace_id`.

---

## BlobOperations (8 APIs)

Access via `ctx.blob` for all blob storage operations.

### Bytes Operations (2)

#### `upload_bytes(container: str, data: bytes, path: str) -> BlobRef`
Upload raw bytes to blob storage.

**Parameters:**
- `container` (str): Target container name
- `data` (bytes): Raw bytes to upload
- `path` (str): Blob path within container

**Returns:** `BlobRef` with URI, etag, and version_id

**Example:**
```python
data = b"Hello, World!"
ref = await ctx.blob.upload_bytes(
    container="results",
    data=data,
    path=f"messages/{ctx.envelope.message_id}.bin"
)
print(ref.uri)  # "azblob://results/messages/abc-123.bin"
```

#### `download_bytes(blob_ref: str | BlobRef) -> bytes`
Download blob as raw bytes.

**Parameters:**
- `blob_ref`: Blob URI string or BlobRef object

**Returns:** bytes

**Example:**
```python
data = await ctx.blob.download_bytes("azblob://input/file.bin")
print(len(data))  # Size in bytes
```

### JSON Operations (2)

#### `upload_json(container: str, obj: dict, path: str) -> BlobRef`
Upload Python dict/list as JSON blob.

**Parameters:**
- `container` (str): Target container
- `obj` (dict | list): JSON-serializable Python object
- `path` (str): Blob path

**Returns:** `BlobRef`

**Example:**
```python
result = {"status": "success", "rows_processed": 1000}
ref = await ctx.blob.upload_json(
    container="results",
    obj=result,
    path=f"reports/{ctx.idempotency_key}.json"
)
```

#### `download_json(blob_ref: str | BlobRef) -> dict | list`
Download and parse JSON blob.

**Parameters:**
- `blob_ref`: Blob URI string or BlobRef

**Returns:** Parsed JSON object (dict or list)

**Example:**
```python
config = await ctx.blob.download_json("azblob://config/settings.json")
print(config["max_retries"])  # 3
```

### Text Operations (2) - NEW in v0.1.1

#### `upload_text(container: str, text: str, path: str) -> BlobRef`
Upload text string to blob storage.

**Parameters:**
- `container` (str): Target container
- `text` (str): Text content to upload (must be a string)
- `path` (str): Blob path

**Returns:** `BlobRef`

**Raises:**
- `TypeError`: If `text` is not a string (e.g., passing a list or dict). Use `upload_json()` for dict/list data.

**Example:**
```python
report = "Processing Summary\n" + "=" * 50 + "\n"
report += f"Rows: 1000\nErrors: 0\n"
ref = await ctx.blob.upload_text(
    container="reports",
    text=report,
    path=f"summaries/{ctx.envelope.message_id}.txt"
)
```

#### `download_text(blob_ref: str | BlobRef) -> str`
Download blob as text string.

**Parameters:**
- `blob_ref`: Blob URI string or BlobRef

**Returns:** Text string (decoded as UTF-8)

**Example:**
```python
content = await ctx.blob.download_text("azblob://logs/app.log")
for line in content.split("\n"):
    if "ERROR" in line:
        print(line)
```

### Streaming Operations (2) - NEW in v0.1.1

#### `upload_stream(container: str, stream: AsyncIterator[bytes], path: str) -> BlobRef`
Upload data from async byte stream (for large files).

**Parameters:**
- `container` (str): Target container
- `stream` (AsyncIterator[bytes]): Async generator yielding chunks
- `path` (str): Blob path

**Returns:** `BlobRef`

**Example:**
```python
async def file_chunks():
    with open("large_file.bin", "rb") as f:
        while chunk := f.read(8192):
            yield chunk

ref = await ctx.blob.upload_stream(
    container="uploads",
    stream=file_chunks(),
    path="large_files/data.bin"
)
```

#### `download_stream(blob_ref: str | BlobRef) -> AsyncIterator[bytes]`
Download blob as async byte stream (for large files).

**Parameters:**
- `blob_ref`: Blob URI string or BlobRef

**Returns:** AsyncIterator[bytes] yielding chunks

**Example:**
```python
total_size = 0
async for chunk in ctx.blob.download_stream("azblob://large/file.bin"):
    total_size += len(chunk)
    # Process chunk...
print(f"Total: {total_size} bytes")
```

---

## Error Handling (3 Error Types)

### `errors.Retryable`
Raised for transient errors that should be retried with backoff.

**Use Cases:**
- Network timeouts
- Rate limiting (HTTP 429)
- Temporary service unavailability
- Transient blob storage errors

**Constructor:** *(Updated in v0.1.5)*
```python
errors.Retryable(message: str, user_message: str | None = None)
```

**Parameters:**
- `message` (str): Internal error message (logged, may be hidden from caller)
- `user_message` (str, optional): Custom user-facing message *(New in v0.1.5)*

**Example:**
```python
from kbm_ledsas_sdk import errors

try:
    data = await external_api_call()
except TimeoutError:
    # Basic usage
    raise errors.Retryable("API timeout - will retry")

    # With custom user message (v0.1.5)
    raise errors.Retryable(
        "Internal: connection pool exhausted after 30s",
        user_message="Service temporarily unavailable, please wait"
    )
```

**SDK Behavior:**
- Automatic exponential backoff: `min(1.0 * 2^retry_count + jitter, 60.0)` seconds
- Configurable max retries via `KBM_LEDSAS_MAX_RETRIES` (default: 3)
- After max retries, message goes to DLQ

### `errors.Permanent`
Raised for non-recoverable errors that should go to Dead Letter Queue.

**Use Cases:**
- Invalid input data
- Missing required fields
- Schema validation failures
- Business logic violations

**Constructor:** *(Updated in v0.1.5)*
```python
errors.Permanent(message: str, user_message: str | None = None)
```

**Parameters:**
- `message` (str): Internal error message (logged, may be hidden from caller)
- `user_message` (str, optional): Custom user-facing message *(New in v0.1.5)*

**Example:**
```python
if not req.get("dataset_uri"):
    # Basic usage
    raise errors.Permanent("Missing required field: dataset_uri")

    # With custom user message (v0.1.5)
    raise errors.Permanent(
        "Validation failed: dataset_uri is None, req keys: ['foo', 'bar']",
        user_message="Missing required field: dataset_uri"
    )
```

**SDK Behavior:**
- Message sent to DLQ immediately
- No retries attempted
- Includes error details for debugging (unless generic_errors=true)

### `errors.DeadlineExceeded`
Raised when processing cannot complete within deadline.

**Use Cases:**
- Not enough time remaining to start safely
- Long-running operations that can't finish
- Resource contention delays

**Example:**
```python
from datetime import datetime, timezone, timedelta

if ctx.deadline:
    time_remaining = ctx.deadline - datetime.now(timezone.utc)
    if time_remaining < timedelta(seconds=10):
        raise errors.DeadlineExceeded(
            f"Only {time_remaining.seconds}s remaining - need at least 10s"
        )
```

**SDK Behavior:**
- Message may be retried if deadline extended
- Logged as timeout rather than failure
- Handler cancelled if deadline exceeded during execution

---

## Timeout Enforcement *(New in v0.1.5)*

The SDK enforces handler execution timeouts to prevent runaway processing.

### Configuration

```bash
export KBM_LEDSAS_HANDLER_TIMEOUT=1800  # 30 minutes (default)
export KBM_LEDSAS_HANDLER_TIMEOUT=0     # Disable timeout
```

### Behavior

When `KBM_LEDSAS_HANDLER_TIMEOUT` > 0:

1. SDK wraps handler execution with `asyncio.wait_for()`
2. If handler exceeds timeout, `asyncio.CancelledError` is raised
3. SDK catches cancellation and treats it as a timeout error
4. Error response sent to caller with code `Timeout`

### Cancellation Safety

**Important:** Handlers should be cancellation-safe. Use `try/finally` blocks to clean up resources:

```python
@app.handler("ProcessData")
async def handle(ctx, req: dict) -> dict:
    resource = None
    try:
        resource = await acquire_resource()
        # Long-running processing...
        result = await process_data(resource, req)
        return {"status": "success", "result": result}
    finally:
        # Always cleanup, even on cancellation
        if resource:
            await release_resource(resource)
```

### Checking Remaining Time

Use `ctx.deadline` to check remaining time proactively:

```python
@app.handler("ProcessData")
async def handle(ctx, req: dict) -> dict:
    if ctx.deadline:
        remaining = (ctx.deadline - datetime.now(timezone.utc)).total_seconds()
        if remaining < 30:
            raise errors.DeadlineExceeded(f"Only {remaining:.0f}s remaining")

    # Proceed with processing...
```

---

## Retry Mechanism *(New in v0.1.5)*

The SDK provides automatic retry with exponential backoff for transient errors.

### Configuration

```bash
export KBM_LEDSAS_MAX_RETRIES=3  # Default: 3 attempts
```

### Behavior

When a handler raises `errors.Retryable`:

1. SDK increments retry counter (stored in message headers)
2. If retry count < `KBM_LEDSAS_MAX_RETRIES`:
   - Calculate backoff: `min(1.0 * 2^retry_count + jitter, 60.0)` seconds
   - Wait for backoff duration
   - Requeue message for retry
3. If retry count >= max retries:
   - Send message to Dead Letter Queue (DLQ)
   - Log error with final retry count

### Backoff Schedule

| Retry | Base Delay | With Jitter (example) |
|-------|------------|----------------------|
| 1 | 2s | 2.1s - 2.9s |
| 2 | 4s | 4.2s - 4.8s |
| 3 | 8s | 8.1s - 8.9s |
| 4+ | 60s (max) | 60.0s - 60.9s |

### Example

```python
@app.handler("ProcessData")
async def handle(ctx, req: dict) -> dict:
    try:
        result = await call_external_service(req["url"])
        return {"status": "success", "data": result}
    except ConnectionError:
        # Will be retried up to MAX_RETRIES times
        raise errors.Retryable(
            "External service connection failed",
            user_message="Service temporarily unavailable"
        )
    except ValueError as e:
        # Will NOT be retried - goes straight to DLQ
        raise errors.Permanent(f"Invalid input: {e}")
```

---

## Generic Error Messages *(New in v0.1.5)*

Enable generic error messages to hide internal error details from callers.

### Configuration

```bash
export KBM_LEDSAS_GENERIC_ERRORS=true   # Hide internal details
export KBM_LEDSAS_GENERIC_ERRORS=false  # Show full details (default)
```

### Behavior

When `KBM_LEDSAS_GENERIC_ERRORS=true`:

| Error Code | Generic Message |
|------------|-----------------|
| `Retryable` | "Processing failed temporarily" |
| `Permanent` | "Processing failed" |
| `Timeout` | "Processing timed out" |
| `UnexpectedError` | "An unexpected error occurred" |
| `HandlerNotFound` | "Handler not available" |

### Custom User Messages

The `user_message` parameter overrides generic messages:

```python
# When generic_errors=true:

# Without user_message:
raise errors.Retryable("DB connection pool exhausted")
# Caller sees: "Processing failed temporarily"

# With user_message:
raise errors.Retryable(
    "DB connection pool exhausted after 30s timeout",
    user_message="Database temporarily unavailable, retrying..."
)
# Caller sees: "Database temporarily unavailable, retrying..."
```

### Logging

Internal error details are always logged regardless of `generic_errors` setting:

```json
{
  "level": "ERROR",
  "message": "Handler error",
  "error_code": "Retryable",
  "internal_message": "DB connection pool exhausted after 30s timeout",
  "user_message": "Database temporarily unavailable, retrying...",
  "correlation_id": "abc-123"
}
```

---

## Supporting Types

### `BlobRef`
Reference to a blob storage object.

**Properties:**
- `uri` (str): Full blob URI (e.g., "azblob://container/path")
- `container` (str): Container name
- `path` (str): Blob path within container
- `etag` (str): Entity tag for versioning
- `version_id` (Optional[str]): Blob version identifier

**Class Methods:**
- `BlobRef.from_uri(uri: str) -> BlobRef`: Parse URI string into BlobRef

**Example:**
```python
from kbm_ledsas_sdk.models import BlobRef

# Parse URI
ref = BlobRef.from_uri("azblob://data/input.json")
print(ref.container)  # "data"
print(ref.path)        # "input.json"

# Use in download
data = await ctx.blob.download_json(ref)
```

---

## Complete Example: Using All APIs

```python
from datetime import datetime, timezone, timedelta
from kbm_ledsas_sdk import ServiceApp, errors
from kbm_ledsas_sdk.models import BlobRef

app = ServiceApp(service_name="complete-example")

@app.handler("ProcessData")  # Handler for "ProcessData" commands
async def handle(ctx, req: dict) -> dict:
    """
    Complete example showing all 19 SDK APIs.

    Args:
        ctx: ExecutionContext with all SDK operations
        req: Request dict with input_uri and options

    Returns:
        dict: Response with result_uri and rows_processed
    """
    # === Context Properties (5) ===
    ctx.logger.info("Starting",
        message_id=ctx.envelope.message_id,
        correlation_id=ctx.correlation_id,
        idempotency_key=ctx.idempotency_key
    )

    # === Deadline Check ===
    if ctx.deadline and datetime.now(timezone.utc) > ctx.deadline - timedelta(seconds=5):
        raise errors.DeadlineExceeded("Not enough time remaining")

    # === Status Reporting (1) ===
    await ctx.emit_status("downloading", 0.0, "Starting download")

    # === Blob Operations (8 methods) ===
    try:
        # Download (bytes, json, text)
        input_uri = req.get("input_uri")
        data_bytes = await ctx.blob.download_bytes(input_uri)
        config = await ctx.blob.download_json("azblob://config/settings.json")
        readme = await ctx.blob.download_text("azblob://docs/README.txt")

        # Process data
        await ctx.emit_status("processing", 0.5, f"Processing {len(data_bytes)} bytes")
        rows = len(data_bytes.split(b"\n"))

        # Upload (bytes, json, text)
        result = {"rows": rows, "options": req.get("options", {})}
        result_ref = await ctx.blob.upload_json(
            container="results",
            obj=result,
            path=f"output/{ctx.idempotency_key}.json"
        )

        # Upload summary as text
        summary = f"Processed {rows} rows successfully"
        await ctx.blob.upload_text(
            container="logs",
            text=summary,
            path=f"summaries/{ctx.envelope.message_id}.txt"
        )

        await ctx.emit_status("done", 1.0, "Complete")
        return {
            "result_uri": result_ref.uri,
            "rows_processed": rows,
            "status": "success"
        }

    except TimeoutError:
        # Retryable error
        raise errors.Retryable("Network timeout")
    except ValueError as e:
        # Permanent error
        raise errors.Permanent(f"Invalid data: {e}")

if __name__ == "__main__":
    app.run()
```

---

**Version:** 0.1.5
**Release:** 2026-01-21
**Total APIs:** 20 (9 context + 8 blob + 3 errors)
**New in v0.1.5:** Timeout enforcement, retry mechanism, generic error messages, user_message parameter
