#!/usr/bin/env python3
"""
LEDSAS SDK - Direct Mode Example (v0.1.5)

This example demonstrates a complete CSV processor service running in Direct Mode.
Direct Mode is suitable for development, testing, and simple deployments.

Architecture (Direct Mode):
    Service → RabbitMQ (direct AMQP connection)
    Service → Azure Blob Storage (direct HTTPS connection)

Prerequisites:
    - RabbitMQ running (amqp://localhost:5672)
    - Azure Blob Storage or Azurite (localhost:10000)
    - kbm-ledsas-sdk installed

Run:
    export KBM_LEDSAS_MODE=direct
    export KBM_LEDSAS_RABBITMQ_URL="amqp://guest:guest@localhost:5672/"
    export KBM_LEDSAS_BLOB_CONN_STRING="DefaultEndpointsProtocol=http;..."

    # New in v0.1.5 - Error handling configuration:
    export KBM_LEDSAS_HANDLER_TIMEOUT=1800      # 30 min timeout (default)
    export KBM_LEDSAS_MAX_RETRIES=3             # Retry count (default)
    export KBM_LEDSAS_GENERIC_ERRORS=false      # Show detailed errors

    python direct_mode_example.py
"""

import logging
from datetime import datetime, timezone, timedelta
from kbm_ledsas_sdk import ServiceApp, errors

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Create service application
app = ServiceApp(service_name="csv-processor-direct")


@app.handler("ProcessCSV")  # Handler for "ProcessCSV" command messages
async def process_csv(ctx, req: dict):
    """
    CSV processing handler - runs for each message received from RabbitMQ.

    Args:
        ctx: ExecutionContext with access to blob operations, message metadata
        req: The request dict with csv_uri

    Returns:
        dict: Response with result_uri and statistics
    """
    logger.info(
        f"Processing CSV file: {req.get('csv_uri')}",
        extra={"correlation_id": ctx.correlation_id}
    )

    # v0.1.5: Check deadline before starting expensive operations
    if ctx.deadline:
        remaining = (ctx.deadline - datetime.now(timezone.utc)).total_seconds()
        if remaining < 30:
            raise errors.DeadlineExceeded(
                f"Only {remaining:.0f}s remaining, need at least 30s for processing"
            )

    # 1. Extract CSV URI from request (v0.1.5: use errors with user_message)
    csv_uri = req.get("csv_uri")
    if not csv_uri:
        raise errors.Permanent(
            "Validation error: csv_uri field is required but was None",
            user_message="Missing required field: csv_uri"
        )

    try:
        # 2. Download CSV from blob storage
        logger.info(f"Downloading CSV from {csv_uri}")
        csv_content = await ctx.blob.download_text(csv_uri)

        # 3. Process CSV (simple example: count lines and validate)
        lines = csv_content.strip().split('\n')
        header = lines[0] if lines else ""
        data_rows = lines[1:] if len(lines) > 1 else []

        logger.info(f"CSV has {len(data_rows)} data rows")

        # 4. Validate CSV structure
        if not header:
            return {
                "status": "error",
                "error_message": "CSV file is empty"
            }

        # 5. Process data (example: convert to uppercase)
        processed_lines = [header]
        for row in data_rows:
            processed_row = row.upper()
            processed_lines.append(processed_row)

        processed_content = '\n'.join(processed_lines)

        # 6. Upload processed result back to blob storage
        # Generate output path based on input
        result_path = csv_uri.replace('.csv', '_processed.csv')
        result_blob_name = _extract_path(result_path)

        result_ref = await ctx.blob.upload_text(
            container=_extract_container(csv_uri),
            text=processed_content,
            path=result_blob_name
        )

        logger.info(f"Uploaded processed result to {result_ref.uri}")

        # 7. Return success response
        return {
            "status": "success",
            "result_uri": result_ref.uri,
            "statistics": {
                "input_rows": len(data_rows),
                "output_rows": len(data_rows),
                "header_columns": len(header.split(',')),
            }
        }

    except ConnectionError as e:
        # v0.1.5: Transient errors - will be retried with backoff
        logger.warning(f"Connection error: {e}")
        raise errors.Retryable(
            f"Blob storage connection failed: {e}",
            user_message="Storage temporarily unavailable, retrying..."
        )

    except Exception as e:
        # v0.1.5: Unexpected errors - logged with details, generic message to caller
        logger.error(f"Error processing CSV: {e}", exc_info=True)
        raise errors.Permanent(
            f"Unexpected error processing CSV: {e}",
            user_message="Failed to process CSV file"
        )


def _extract_container(uri: str) -> str:
    """Extract container name from azblob:// URI"""
    # azblob://container/path/to/file.csv → container
    return uri.replace("azblob://", "").split('/')[0]


def _extract_path(uri: str) -> str:
    """Extract path from azblob:// URI"""
    # azblob://container/path/to/file.csv → path/to/file.csv
    parts = uri.replace("azblob://", "").split('/', 1)
    return parts[1] if len(parts) > 1 else ""


if __name__ == "__main__":
    """
    Usage:
        # 1. Start infrastructure (RabbitMQ + Azurite)
        cd 3-local-development
        docker compose up -d

        # 2. Set environment variables
        export KBM_LEDSAS_MODE=direct
        export KBM_LEDSAS_RABBITMQ_URL="amqp://guest:guest@localhost:5672/"
        export KBM_LEDSAS_BLOB_CONN_STRING="DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;"

        # 3. Run service
        python direct_mode_example.py
    """
    logger.info("Starting CSV Processor (Direct Mode)")
    logger.info("Press Ctrl+C to stop")
    app.run()
