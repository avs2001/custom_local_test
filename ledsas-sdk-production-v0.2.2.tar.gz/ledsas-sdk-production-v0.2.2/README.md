# LEDSAS SDK - Production-Mode Package

**SDK version:** 0.2.2
**Sidecar version:** 0.2.2

> **Production mode** runs your service against the `kbm-ledsas-agent`
> sidecar over a Unix domain socket (UDS). The sidecar owns the
> RabbitMQ + Azure Blob connections, enforces topology/security policy,
> and runs in its own process or container. This is the artifact that
> ships through Kubyk CI/CD to real environments. For local laptop
> development against RabbitMQ + Azurite directly, use the
> direct-mode tarball instead.

---

## What is This Package?

This package contains everything you need to deploy a LEDSAS service in
production:

- The SDK wheel — UDS-mode customer surface (`1-sdk/`).
- The `kbm-ledsas-agent` sidecar wheel (`1-sidecar/`).
- An example Kubernetes deployment manifest + sidecar startup notes
  (`2-kubernetes-deployment/`).
- Quickstart, API reference, and a runnable UDS example
  (`3-documentation/`).
- License + third-party notices (`4-legal/`).

What's new in this release: see [`CHANGELOG.md`](CHANGELOG.md).

---

## SDK ↔ Sidecar Version Compatibility

| SDK version | Sidecar version | Compatible? |
|-------------|-----------------|-------------|
| 0.2.2       | 0.2.2           | yes (matched pair — **current release**; functionally identical to 0.2.0/0.2.1 — no SDK or sidecar behavior change) |
| 0.2.0–0.2.1 | 0.2.0–0.2.1     | yes (matched pairs; full chunked upload support) |
| 0.2.0       | 0.1.8           | yes for payloads ≤ 7 MiB — the SDK automatically falls back to single-RPC `blob.upload` (with a WARNING log) when chunked init returns `METHOD_NOT_FOUND`. Payloads > 7 MiB fail with a clear "Upgrade the sidecar to v0.2.0" error. |
| 0.1.8       | 0.2.0           | yes — SDK never invokes chunked methods; sidecar still accepts the canonical `data` key on `blob.upload`. |
| 0.1.8       | 0.1.8           | yes (previous matched pair) |
| 0.1.8       | 0.1.1–0.1.7     | yes — sidecar accepts the legacy `data_base64` key on `blob.upload` for one release as a transition window |
| ≤ 0.1.7     | 0.1.8           | yes — SDK still sends `data_base64`; sidecar accepts both |
| ≤ 0.1.7     | ≤ 0.1.7         | **broken** — UDS-mode `upload_bytes` fails `INVALID_PARAMS` (`data_base64` ↔ `data` mismatch; fixed in v0.1.8). Upgrade the SDK or the sidecar to v0.1.8 to recover. |

> The `data_base64` ↔ `data` field-name mismatch is the latent bug
> closed in TASK-025. The contract test that locks the wire shape lives
> at `kbm_ledsas_sdk/tests/contracts/test_rpc_field_symmetry.py`.

---

## Quick Start

The full setup walkthrough lives at
[`3-documentation/QUICKSTART_PRODUCTION_MODE.md`](3-documentation/QUICKSTART_PRODUCTION_MODE.md).
The minimum-viable install (verifies both wheels import cleanly) is:

```bash
cd ledsas-sdk-production-v0.2.2

# A virtual environment is required: modern macOS (Homebrew) and Ubuntu
# refuse system-wide pip installs (PEP 668 "externally-managed-environment").
python3 -m venv venv
source venv/bin/activate

# Upgrade pip + setuptools to close known stdlib-venv CVEs.
pip install --upgrade pip setuptools

# Install the SDK wheel
pip install 1-sdk/kbm_ledsas_sdk-0.2.2-py3-none-any.whl

# Verify the SDK imports
python -c "from kbm_ledsas_sdk import ServiceApp; print('SDK installed.')"

# The sidecar wheel is installed in the sidecar container (or a
# separate venv), not alongside your service:
pip install 1-sidecar/kbm_ledsas_agent-0.2.2-py3-none-any.whl
python -m kbm_ledsas_agent --help 2>/dev/null || python kbm-ledsas-agent/main.py --help
```

> **Reproducible install (regulated environments):** the SDK
> lockfile is at `1-sdk/requirements.lock.txt`.
>
> ```bash
> pip install -r 1-sdk/requirements.lock.txt
> pip install 1-sdk/kbm_ledsas_sdk-0.2.2-py3-none-any.whl
> ```

---

## Next Steps

1. **Quick Start:**
   [`3-documentation/QUICKSTART_PRODUCTION_MODE.md`](3-documentation/QUICKSTART_PRODUCTION_MODE.md)
   — sidecar bring-up, env vars, UDS socket path, first request.

2. **Kubernetes deployment:**
   [`2-kubernetes-deployment/README.md`](2-kubernetes-deployment/README.md)
   — example manifest (service container + sidecar sidecar-container),
   shared `emptyDir` volume for the UDS socket, env-var wiring.

3. **Sidecar startup:**
   [`2-kubernetes-deployment/sidecar-startup.md`](2-kubernetes-deployment/sidecar-startup.md)
   — required env vars, health endpoints, signal handling, log format.

4. **SDK API Reference:**
   [`3-documentation/SDK_API_REFERENCE.md`](3-documentation/SDK_API_REFERENCE.md)
   — UDS-mode-specific behavior (`ServiceApp`, `ExecutionContext`,
   blob operations, RPC error mapping).

5. **Runnable example:**
   [`3-documentation/examples/uds_mode_example.py`](3-documentation/examples/uds_mode_example.py)
   — minimal handler that connects to a local sidecar and round-trips
   a command.

---

## Package Contents

```
ledsas-sdk-production-v0.2.2/
├── README.md                       # This file
├── CHANGELOG.md                    # Release notes
│
├── 1-sdk/                          # Customer-installed SDK
│   ├── kbm_ledsas_sdk-0.2.2-py3-none-any.whl
│   ├── requirements.lock.txt       # pinned transitives for reproducible install
│   └── wheel.sha256
│
├── 1-sidecar/                      # Sidecar (deployed alongside service)
│   ├── kbm_ledsas_agent-0.2.2-py3-none-any.whl
│   └── wheel.sha256
│
├── 2-kubernetes-deployment/
│   ├── README.md
│   ├── deployment.yaml.example
│   └── sidecar-startup.md
│
├── 3-documentation/
│   ├── QUICKSTART_PRODUCTION_MODE.md
│   ├── SDK_API_REFERENCE.md
│   └── examples/
│       └── uds_mode_example.py
│
└── 4-legal/
    ├── LICENSE.txt
    └── THIRD_PARTY_NOTICES.txt
```

---

## Production vs Direct Mode

| Concern | Direct mode | Production mode (this package) |
|---|---|---|
| Transport | SDK ↔ RabbitMQ/Azure direct | SDK ↔ sidecar over UDS; sidecar ↔ RabbitMQ/Azure |
| Customer credentials | Customer service holds Azure + RabbitMQ creds | Customer service holds nothing; sidecar holds them |
| Deployment shape | Single container (your service) | Two containers / sidecar pattern (service + sidecar in one Pod) |
| Topology policy | Customer service enforces | Sidecar enforces (single source of truth) |
| Use case | Local dev, prototype, CI tests | Kubyk-deployed production |

You write the same handler code either way — pick the mode at runtime
via `KBM_LEDSAS_MODE=production` (uses UDS) vs `KBM_LEDSAS_MODE=direct`
(uses RabbitMQ/Azure directly).

---

## Handling Sensitive Data

The same caveats from the direct-mode README apply: encryption at rest,
transport encryption, log retention, and avoiding identifiable values
in `trace_id`, `idempotency_key`, `job_id`, or `reply_to`. Production
mode additionally:

- Centralizes credential exposure in the sidecar process (smaller
  attack surface than direct mode where every service has the creds).
- Logs every RPC call on the sidecar — review your retention policy.
- Refuses cleartext `amqp://` to non-loopback hosts unless
  `KBM_LEDSAS_ALLOW_INSECURE_AMQP=1` is set (escape hatch — see API
  reference).

Consult your compliance team before deploying.

---

## Support

For questions or issues:

1. Check [`3-documentation/QUICKSTART_PRODUCTION_MODE.md`](3-documentation/QUICKSTART_PRODUCTION_MODE.md) for troubleshooting.
2. Review the API reference and `2-kubernetes-deployment/` notes.
3. Contact KeborMed support.

---

## License

See [`4-legal/LICENSE.txt`](4-legal/LICENSE.txt) for licensing information.

---

**Ready to start?** Go to [`3-documentation/QUICKSTART_PRODUCTION_MODE.md`](3-documentation/QUICKSTART_PRODUCTION_MODE.md).
