#!/usr/bin/env python3
"""
Simple CSV Processor - Minimal LEDSAS SDK Example
==================================================

This is the simplest possible LEDSAS microservice implementation.
Use this as a starting point for building your own service.

Requirements:
- Python 3.11+
- kbm-ledsas-sdk 0.1.5+
- Local RabbitMQ and Azurite running (see 3-local-development/)

Environment Variables:
    KBM_LEDSAS_MODE=direct
    KBM_LEDSAS_RABBITMQ_URL=amqp://guest:guest@localhost:5672/
    KBM_LEDSAS_BLOB_CONN_STRING=DefaultEndpointsProtocol=http;...

    # New in v0.1.5:
    KBM_LEDSAS_HANDLER_TIMEOUT=1800      # Handler timeout (seconds)
    KBM_LEDSAS_MAX_RETRIES=3             # Max retry attempts
    KBM_LEDSAS_GENERIC_ERRORS=false      # Hide error details from callers

Usage:
    python simple_csv_processor.py
"""

import asyncio
import logging
from kbm_ledsas_sdk import ServiceApp, errors

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Create service application
app = ServiceApp(service_name="simple-csv-processor")


@app.handler("ProcessCSV")  # Handler for "ProcessCSV" command messages
async def handle_csv_request(ctx, req: dict):
    """
    Process a CSV file request.

    Args:
        ctx: ExecutionContext with request envelope and SDK operations
        req: Request dict with input_csv_uri and output_container

    Returns:
        dict: Response with result_uri and status

    Raises:
        Exception: On processing errors (SDK handles retries)
    """
    # 1. Extract request data
    input_csv_uri = req.get("input_csv_uri")
    output_container = req.get("output_container", "output")

    # Validate required field (v0.1.5: use user_message for caller-friendly errors)
    if not input_csv_uri:
        raise errors.Permanent(
            "Validation error: input_csv_uri is required but was None",
            user_message="Missing required field: input_csv_uri"
        )

    logger.info(f"Processing CSV: {input_csv_uri}")

    # 2. Download CSV from blob storage
    csv_data = await ctx.blob.download_text(input_csv_uri)

    # 3. Process CSV (simple example: count rows)
    lines = csv_data.strip().split('\n')
    row_count = len(lines) - 1  # Subtract header row

    result = {
        "input_uri": input_csv_uri,
        "row_count": row_count,
        "status": "processed"
    }

    logger.info(f"Processed {row_count} rows")

    # 4. Upload result to blob storage
    result_blob_name = f"result-{ctx.envelope.message_id}.json"
    result_ref = await ctx.blob.upload_json(
        container=output_container,
        obj=result,
        path=result_blob_name
    )

    logger.info(f"Result uploaded to: {result_ref.uri}")

    # 5. Return response
    return {
        "result_uri": result_ref.uri,
        "row_count": row_count,
        "status": "success"
    }


if __name__ == "__main__":
    logger.info("Starting Simple CSV Processor...")
    logger.info("Press Ctrl+C to stop")
    app.run()
