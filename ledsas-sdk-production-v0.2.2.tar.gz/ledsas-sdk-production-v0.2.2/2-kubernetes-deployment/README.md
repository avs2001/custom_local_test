# Kubernetes Deployment

This directory documents how to run a LEDSAS service in production. The
deployment shape is the **sidecar pattern**: your service container and
the `kbm-ledsas-agent` sidecar container share a Pod and communicate
over a Unix domain socket on a shared `emptyDir` volume.

## Files

| File | Purpose |
|------|---------|
| `deployment.yaml.example` | Annotated K8s Deployment manifest you can copy as a starting point. |
| `sidecar-startup.md` | Required env vars, signal handling, health probes, logging. |

## Why a Sidecar?

- Your service holds no Azure or RabbitMQ credentials. Credential
  rotation only touches the sidecar.
- Topology policy (queue names, DLX, retry budgets, payload size caps)
  is enforced once, in the sidecar, not in every service.
- The SDK talks UDS — fast, no network surface, file-permission gated.

## Kubyk Note

The example manifest is intentionally Kubyk-agnostic. Kubyk imposes
additional conventions (image registry layout, service-account naming,
secret-injection mechanism). The Kubyk-specific contract is being
formalized in a follow-up task and will live at
`docs/architecture/kubyk-ledsas-contract.md` once available. Until
then, your platform team has the working details — this README + the
example manifest are the generic skeleton.

## Minimum Viable Pod Shape

```yaml
spec:
  containers:
    - name: app
      image: your-registry/your-service:tag
      env:
        - name: KBM_LEDSAS_MODE
          value: "production"
        - name: KBM_LEDSAS_SOCKET_PATH
          value: "/run/kbm-ledsas/agent.sock"
        - name: KBM_LEDSAS_SERVICE_NAME
          value: "your-service-name"
      volumeMounts:
        - name: ledsas-socket
          mountPath: /run/kbm-ledsas

    - name: ledsas-agent
      image: your-registry/kbm-ledsas-agent:0.2.2
      env:
        - name: SOCKET_PATH
          value: "/run/kbm-ledsas/agent.sock"
        - name: SERVICE_NAME
          value: "your-service-name"
        # ... + RABBITMQ_HOST, RABBITMQ_USER, RABBITMQ_PASSWORD, BLOB_CONN_STRING
        # (from K8s Secrets — see deployment.yaml.example)
      volumeMounts:
        - name: ledsas-socket
          mountPath: /run/kbm-ledsas
      livenessProbe:
        httpGet:
          path: /health
          port: 8080
      readinessProbe:
        httpGet:
          path: /ready
          port: 8080

  volumes:
    - name: ledsas-socket
      emptyDir: {}

  terminationGracePeriodSeconds: 60   # let in-flight handlers finish
```

See `deployment.yaml.example` for the fully-annotated version with
Secrets, ServiceAccount, and resource limits.
